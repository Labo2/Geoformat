<?php 		

$gp_options = get_option( 'gp_options' );
$meta_font = $gp_options['font_text'];
$meta_font_title = $gp_options['font_title'];
$meta_color = $gp_options['primary_color'];
$meta_colorb = $gp_options['secondary_color'];

	/**
	  *Fonts and colors
	***/
	if( !empty( $meta_font)) {?> 
	<?php if ($meta_font == "select-seven") { ?>	
		<link href='https://fonts.googleapis.com/css?family=Droid+Sans:400,700' rel='stylesheet' type='text/css'> 	
		<?php } else if ($meta_font == "select-eight") { ?> <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font == "select-six") { ?> <link href='https://fonts.googleapis.com/css?family=Arvo:400,700' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font == "select-nine") { ?> <link href='https://fonts.googleapis.com/css?family=Roboto:400,700' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font == "select-ten") { ?> <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,700' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font == "select-eleven") { ?> <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'> 
		<?php } else if ($meta_font == "select-twelve") { ?> <link href='https://fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font == "select-thirteen") { ?> <link href='https://fonts.googleapis.com/css?family=Inconsolata' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font == "select-fourteen") { ?> <link href='https://fonts.googleapis.com/css?family=Playfair+Display' rel='stylesheet' type='text/css'> 
	<?php } if( !empty( $meta_font_title) ) {?>	
		<?php if ($meta_font_title == "select-one") { ?> 	<link href='https://fonts.googleapis.com/css?family=Droid+Sans:400,700' rel='stylesheet' type='text/css'> 	
		<?php } else if ($meta_font_title == "select-two") { ?> <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font_title  == "select-three") { ?> <link href='https://fonts.googleapis.com/css?family=Arvo:400,700' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font_title == "select-four") { ?> 	<link href='https://fonts.googleapis.com/css?family=Roboto:400,700' rel='stylesheet' type='text/css'> 
		<?php } else if ($meta_font_title == "select-five") { ?> <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,700' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font_title == "select-six") { ?> <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'> 
		<?php } else if ($meta_font_title == "select-seven" || $meta_font == "select-twelve") { ?> <link href='https://fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font_title == "select-eight") { ?> <link href='https://fonts.googleapis.com/css?family=Inconsolata' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font_title == "select-nine") { ?> <link href='https://fonts.googleapis.com/css?family=Playfair+Display' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font_title == "select-ten") { ?> <link href='https://fonts.googleapis.com/css?family=Raleway:600' rel='stylesheet' type='text/css'> 
		<?php } 	
	} 
	
	/**
	  *Geoformat contents
	***/
	
	$meta_date = get_post_meta( get_the_ID(), 'meta-date', true );	
	$section_un = get_post_meta( get_the_ID(), '_wp_editor_section_1', true );
	$section_deux = get_post_meta( get_the_ID(), '_wp_editor_section_2', true );	
	$section_trois = get_post_meta( get_the_ID(), '_wp_editor_section_3', true );	
	$section_quatre = get_post_meta( get_the_ID(), '_wp_editor_section_4', true );	
	$section_cinq = get_post_meta( get_the_ID(), '_wp_editor_section_5', true );	
	$section_img_1 = get_post_meta( get_the_ID(), 'meta-image_1', true );	
	$section_img_2 = get_post_meta( get_the_ID(), 'meta-image_2', true );	
	$section_img_3 = get_post_meta( get_the_ID(), 'meta-image_3', true );	
	$section_img_4 = get_post_meta( get_the_ID(), 'meta-image_4', true );	
	$section_img_5 = get_post_meta( get_the_ID(), 'meta-image_5', true );	
	$section1_caption = get_post_meta( get_the_ID(), 'section1_caption', true );	
	$section2_caption = get_post_meta( get_the_ID(), 'section2_caption', true );	
	$section3_caption = get_post_meta( get_the_ID(), 'section3_caption', true );	
	$section4_caption = get_post_meta( get_the_ID(), 'section4_caption', true );	
	$section5_caption = get_post_meta( get_the_ID(), 'section5_caption', true );	
	$section_video_1 = get_post_meta( get_the_ID(), 'meta-video_1', true );	
	$section_video_2 = get_post_meta( get_the_ID(), 'meta-video_2', true ); 	
	$section_video_3 = get_post_meta( get_the_ID(), 'meta-video_3', true );	
	$section_video_4 = get_post_meta( get_the_ID(), 'meta-video_4', true );	
	$section_video_5 = get_post_meta( get_the_ID(), 'meta-video_5', true );	
	$section_map_1 = get_post_meta( get_the_ID(), 'meta-map_1', true );	
	$section_map_2 = get_post_meta( get_the_ID(), 'meta-map_2', true ); 	
	$section_map_3 = get_post_meta( get_the_ID(), 'meta-map_3', true );	
	$section_map_4 = get_post_meta( get_the_ID(), 'meta-map_4', true );	
	$section_map_5 = get_post_meta( get_the_ID(), 'meta-map_5', true );	
	$section_title_un = get_post_meta( get_the_ID(), 'meta-title_1', true );	
	$section_title_deux = get_post_meta( get_the_ID(), 'meta-title_2', true );	
	$section_title_trois = get_post_meta( get_the_ID(), 'meta-title_3', true );	
	$section_title_quatre = get_post_meta( get_the_ID(), 'meta-title_4', true );	
	$section_title_cinq = get_post_meta( get_the_ID(), 'meta-title_5', true );	
	$top_title = get_post_meta( get_the_ID(), 'section_title_color', true );	
	$sec1_title = get_post_meta( get_the_ID(), 'section1_title_color', true );	
	$sec1_title_align = get_post_meta( get_the_ID(), 'section1_title_align', true );	
	$sec2_title = get_post_meta( get_the_ID(), 'section2_title_color', true );	
	$sec2_title_align = get_post_meta( get_the_ID(), 'section2_title_align', true );	
	$sec3_title = get_post_meta( get_the_ID(), 'section3_title_color', true );	
	$sec3_title_align = get_post_meta( get_the_ID(), 'section3_title_align', true );	
	$sec4_title = get_post_meta( get_the_ID(), 'section4_title_color', true );	
	$sec4_title_align = get_post_meta( get_the_ID(), 'section4_title_align', true );	
	$sec5_title = get_post_meta( get_the_ID(), 'section5_title_color', true );	
	$sec5_title_align = get_post_meta( get_the_ID(), 'section5_title_align', true );	
	$meta_auteur = get_post_meta( get_the_ID(), 'meta-auteur', true );	
	$load_auteur = get_post_meta( get_the_ID(), 'load-auteur', true );	
	$meta_loader = get_post_meta( get_the_ID(), 'meta-loader', true );	
	$meta_loader_animate = get_post_meta( get_the_ID(), 'meta-loader-animate', true );	
	$meta_trigger = get_post_meta( get_the_ID(), 'meta-trigger', true );	
	$trigger_text = get_post_meta( get_the_ID(), 'trigger-text', true );	
	$meta_bar = get_post_meta( get_the_ID(), 'meta-bar', true );	
	$meta_photos = get_post_meta( get_the_ID(), 'meta-photos', true );	
	$meta_top = get_post_meta( get_the_ID(), 'meta-image', true );	
	$meta_font_size = get_post_meta( get_the_ID(), 'meta-font-size', true );	
	$meta_col = get_post_meta( get_the_ID(), 'meta-col', true );	
	$small = "col-lg-6 col-md-6 col-sm-9";		
	$large = "col-lg-8 col-md-8 col-sm-11";	
	$subline = get_post_meta( get_the_ID(), 'meta-subline', true );	
	$chapo = get_post_meta( get_the_ID(), '_wp_editor_chapo', true );	
	$txt = get_post_meta( get_the_ID(), '_wp_editor_text', true );	
	$bar_sup = get_post_meta( get_the_ID(), 'bar-sup', true );
	$bar_title = get_post_meta( get_the_ID(), 'bar-title', true );	
	$top_bar = get_post_meta( get_the_ID(), 'top-bar', true );	
	$reseaux = get_post_meta( get_the_ID(), 'reseaux', true );	
	$burger = get_post_meta( get_the_ID(), 'burger', true );	
	$meta_quote = get_post_meta( get_the_ID(), 'quote-design', true );
	$meta_quote_design = get_post_meta( get_the_ID(), 'quote', true );	
	$intro = get_post_meta( get_the_ID(), 'meta-animate', true );	
	$footer = get_post_meta( get_the_ID(), '_wp_editor_foot', true );
	$custom_css = get_post_meta( get_the_ID(), 'custom-css', true ); 
	?>
	
<style type="text/css"> 	
	<?php 
	if ($meta_font == "select-one") { ?>	
	html, body {font-family: Arial, Helvetica, sans-serif;}	
	<?php } else if ($meta_font == "select-two") { ?>	
	html, body {font-family: Georgia, serif;font-size:1.1em;}	
	.section_title {font-size: 4em;}	
	<?php } else if ($meta_font == "select-three") { ?> 
	html, body {font-family: Tahoma, Geneva, sans-serif;}	
	<?php } else if ($meta_font == "select-four") { ?>	
	html, body {font-family: "Times New Roman", Times, serif;font-size:1.1em;}	
	.section_title {font-size: 4em;}	
	<?php } else if ($meta_font == "select-five") { ?>	
	html, body {font-family: Verdana, Geneva, sans-serif;}	
	<?php } else if ($meta_font == "select-six") { ?>	
	html, body {font-family: 'Arvo', serif;}	
	<?php } else if ($meta_font == "select-seven") { ?>	
	html, body {font-family: 'Droid Sans', sans-serif;}	
	<?php } else if ($meta_font == "select-eight") { ?>	
	html, body {font-family: 'Open Sans', sans-serif;}	<?php } 
	else if ($meta_font == "select-nine") { ?>	
	html, body {font-family: 'Roboto', sans-serif;}	
	<?php } else if ($meta_font == "select-ten") { ?>	
	html, body {font-family:'Roboto Slab', serif;}	
	<?php } else if ($meta_font == "select-eleven") { ?>	
	html, body {font-family: 'Lato', sans-serif;}	
	<?php } else if ($meta_font == "select-twelve") { ?>	
	html, body {font-family: 'Ubuntu Condensed', sans-serif;}	
	<?php } else if ($meta_font == "select-thirteen") { ?>	
	html, body {font-family: 'Inconsolata', cursive;}	
	<?php } else if ($meta_font == "select-fourteen") { ?>	
	html, body {font-family: 'Playfair Display', serif;}	
	
	<?php }	} 	if( !empty( $meta_font_size ) ) {	if ($meta_font_size == "select-two") { ?>	
	html, body {font-size: 1.1em;}	
	<?php } elseif ($meta_font_size == "select-three") { ?>	html, body {font-size:0.9em;}	
	<?php } else { ?> html, body {font-size:1em;}	
	<?php }}	
	
	if( !empty( $sec1_title_align ) ) {	
		if ($sec1_title_align == "select-two" ) { ?>	
		#sec1_title {text-align:center;}
		.map_title{margin-left: 25%;width: 50%;}	
		<?php } elseif ($sec1_title_align == "select-three" ) { ?>	
		.map_title{right: 5%;}
		#sec1_title {text-align:right;margin-right:5%;}	
		<?php } else { ?>
		#sec1_title {text-align:left;margin-left:5%;} 
		<?php } 
	}
	
	if( !empty( $sec2_title_align ) ) { 
		if ($sec2_title_align == "select-two" ) { ?>	
		#sec2_title {text-align:center;}
		.map_title{margin-left: 25%;width: 50%;}	
		<?php } elseif ($sec2_title_align == "select-three" ) { ?>	
		.map_title{right: 5%;}
		#sec2_title {text-align:right;margin-right:5%;}	
		<?php } else { ?>	
		#sec2_title {text-align:left;margin-left:5%;} 
		<?php } 
	}
	
	if( !empty( $sec3_title_align ) ) { 
		if ($sec3_title_align == "select-two" ) { ?>
		#sec3_title {text-align:center;}
		.map_title{margin-left: 25%;width: 50%;}	
		<?php } elseif ($sec3_title_align == "select-three" ) { ?>	
		.map_title{right: 5%;}
		#sec3_title {text-align:right;margin-right:5%;}	<?php } else { ?>	
		#sec3_title {text-align:left;margin-left:5%;} <?php } 
	}	
	
	if ($meta_bar == "select-one") { ?>	#progression {top: 0px;}	
	<?php } elseif ($meta_bar == "select-two") { ?>	#progression {bottom: 0px;}	<?php } 	
	
	if( !empty( $sec4_title_align ) ) {	
		if ($sec4_title_align == "select-two" ) { ?>	
		#sec4_title {text-align:center;}	
		.map_title{margin-left: 25%;width: 50%;}
		<?php } 	
		elseif ($sec4_title_align == "select-three" ) { ?>	
		#sec4_title {text-align:right;margin-right:5%;}
		.map_title{right: 5%;}
		<?php } else { ?>	
		#sec4_title {text-align:left;margin-left:5%;} 
		<?php } 
	}
	
	if( !empty( $sec5_title_align ) ) 
	{	
		if ($sec5_title_align == "select-two" ) { ?>	
		.map_title{margin-left: 25%;width: 50%;}
		#sec5_title {text-align:center;}	<?php } 	
		elseif ($sec5_title_align == "select-three" ) { ?>	
		.map_title{right: 5%;}
		#sec5_title {text-align:right;margin-right:5%;}	<?php } 
		else { ?>	
		#sec5_title {text-align:left;margin-left:5%;} 	
		<?php } 
	}

	/*Titles*/
	if( !empty( $meta_font_title ) ) 
	{	if ($meta_font_title == "select-one") { ?>	
	.title h1, #intro h1, .section_title, #inner h1,.caption_img_slf {font-family: 'Droid Sans', sans-serif;}	.title h1 {font-size: 4.2em;}  
	<?php } else if ($meta_font_title == "select-two") { ?>	
	.title h1, #intro h1, .section_title, #inner h1,.caption_img_slf {font-family: 'Open Sans', sans-serif;}	.title h1 {font-size: 4.2em;}	   	
	<?php } else if ($meta_font_title  == "select-three") { ?>	
	.title h1, #intro h1, .section_title, #inner h1,.caption_img_slf {font-family: 'Arvo', serif;}	.title h1 {font-size: 4.2em;}	.section_title {font-size: 4.1em;} 
	<?php } else if ($meta_font_title == "select-four") { ?>	
	.title h1, #intro h1, .section_title, #inner h1,.caption_img_slf {font-family: 'Roboto', sans-serif;}	.title h1 {font-size: 4.3em;} 
	<?php } else if ($meta_font_title == "select-five") { ?>	
	.title h1, #intro h1, .section_title, #inner h1,.caption_img_slf {font-family: 'Roboto Slab', serif;}	.title h1 {font-size: 4.6em;} 	
	<?php } else if ($meta_font_title == "select-six") { ?>	
	.title h1, #intro h1, .section_title, #inner h1,.caption_img_slf {font-family: 'Lato', sans-serif;}	.title h1 {font-size: 4.6em;}	
	<?php } else if ($meta_font_title == "select-seven") { ?>	
	.title h1, #intro h1, .section_title, #inner h1,.caption_img_slf {font-family: 'Ubuntu Condensed', sans-serif;}	.title h1 {font-size: 4.6em;}	
	<?php } else if ($meta_font_title == "select-eight") { ?>	
	.title h1, #intro h1, .section_title, #inner h1,.caption_img_slf {font-family: 'Inconsolata', cursive;}	.title h1 {font-size: 4.6em;}	
	<?php } else if ($meta_font_title == "select-nine") { ?>	
	.title h1, #intro h1, .section_title, #inner h1,.caption_img_slf {font-family: 'Playfair Display', serif;}	.title h1 {font-size: 4.6em;}	
	<?php } else if ($meta_font_title == "select-ten") { ?>	
	.title h1, #intro h1, .section_title, #inner h1,.caption_img_slf {font-family: 'Raleway', sans-serif;}	.title h1 {font-size: 4.6em;}	
	<?php } }	
	
	if( !empty( $top_title ) ) 
	{ 	
		if ($top_title == "select-two") { ?> 	
		.title h1,.bloc_title_top {color:#000000;}
		
		<?php } 
		elseif ($top_title == "select-three") { ?> 
		.bloc_title_top,.bloc_title_top_map {line-height:180%;color:#FFFFFF;padding:10px 20px;background:<?php echo $meta_color; ?>;margin:0;text-align:center;} 
		<?php } elseif ($top_title == "select-four") { ?> 
		.bloc_title_top,.bloc_title_top_map {line-height:180%;color:#FFFFFF;padding:10px 20px;background:#000000;opacity:0.7;margin:0;text-align:center;} 
		<?php } else { ?> .title h1,.bloc_title_top {color:#FFFFFF;} <?php }  	
	}	
	
	if( !empty( $sec1_title ) ) {  
		if ($sec1_title == "select-two") { ?> 	
		#sec1_title {color:#000000;} 
		<?php } elseif ($sec1_title == "select-three") { ?> 
		#bloc_title_1 {color:#FFFFFF;padding:10px 20px;background:<?php echo $meta_color; ?>;margin:0;text-align:center;} 
		<?php } elseif ($sec1_title == "select-four") { ?> 
		#bloc_title_1 {color:#FFFFFF;padding:10px 20px;background:#000000;margin:0;text-align:center;opacity:0.9;} 
		<?php } else { ?> #sec1_title {color:#FFFFFF;} <?php } 	
	}	
	
	if( !empty( $sec2_title ) ) {  
		if ($sec2_title == "select-two") { ?> 	
		#sec2_title {color:#000000;} 
		<?php } elseif ($sec2_title == "select-three") { ?> 
		#bloc_title_2 {color:#FFFFFF;padding:10px 20px;background:<?php echo $meta_color; ?>;margin:0;text-align:center;} 
		<?php } elseif ($sec2_title == "select-four") { ?> 
		#bloc_title_2 {color:#FFFFFF;padding:10px 20px;background:#000000;margin:0;text-align:center;opacity:0.9;} 
		<?php } else { ?> #sec2_title {color:#FFFFFF;} 
		<?php } 	
	}	
	
	if( !empty( $sec3_title ) ) { 
		if ($sec3_title == "select-two") { ?> 	
		#sec3_title {color:#000000;} 
		<?php } elseif ($sec3_title == "select-three") { ?> 
		#bloc_title_3 {color:#FFFFFF;padding:10px 20px;background:<?php echo $meta_color; ?>;margin:0;text-align:center;} 
		<?php } elseif ($sec3_title == "select-four") { ?> 
		#bloc_title_3 {color:#FFFFFF;padding:10px 20px;background:#000000;margin:0;text-align:center;opacity:0.9;} 
		<?php } else { ?> 
		#sec3_title {color:#FFFFFF;} 
		<?php } 
	}	
	
	if( !empty( $sec4_title ) ) {  
		if ($sec4_title == "select-two") { ?> 	
		#sec4_title {color:#000000;} 
		<?php } elseif ($sec4_title == "select-three") { ?> 
		#bloc_title_4 {color:#FFFFFF;padding:10px 20px;background:<?php echo $meta_color; ?>;margin:0;text-align:center;} 
		<?php } elseif ($sec4_title == "select-four") { ?> 
		#bloc_title_4 {color:#FFFFFF;padding:10px 20px;background:#000000;margin:0;text-align:center;opacity:0.9;} 
		<?php } else { ?> 
		#sec4_title {color:#FFFFFF;} <?php } 	
	}	
	
	if( !empty( $sec5_title ) ) {  
		if ($sec5_title == "select-two") { ?> 	
		#sec5_title  {color:#000000;} 
		<?php } elseif ($sec5_title == "select-three") { ?> 
		#bloc_title_5 {color:#FFFFFF;padding:10px 20px;background:<?php echo $meta_color; ?>;margin:0;text-align:center;} 
		<?php } elseif ($sec5_title == "select-four") { ?> 
		#bloc_title_5 {color:#FFFFFF;padding:10px 20px;background:#000000;margin:0;text-align:center;opacity:0.9;} 
		<?php } else { ?> 
		#sec5_title {color:#FFFFFF;} 
		<?php } 	
	}	
	
	
	if( !empty( $section_img_1 ) ) { ?> 
	#section_un{background: <?php echo $meta_color; ?> url("<?php echo $section_img_1; ?>") center fixed;}	
	<?php } if( !empty( $section_img_2 ) ) { ?> 
	#section_deux{background: <?php echo $meta_color; ?> url("<?php echo $section_img_2; ?>") center fixed;}	
	<?php } if( !empty( $section_img_3 ) ) { ?> 
	#section_trois{background: <?php echo $meta_color; ?> url("<?php echo $section_img_3; ?>") center fixed;}	
	<?php } if( !empty( $section_img_4 ) ) { ?> 
	#section_quatre{background: <?php echo $meta_color; ?> url("<?php echo $section_img_4; ?>") center fixed;}	
	<?php } if( !empty( $section_img_5 ) ) { ?> 
	#section_cinq{background: <?php echo $meta_color; ?> url("<?php echo $section_img_5; ?>") center fixed;}	
	<?php }  
	
	if( !empty( $meta_top ) ) { ?>	
	.page_loader div, .bg-img{background: <?php echo $meta_color; ?> url('<?php echo $meta_top; ?>') no-repeat center center fixed; 
	-webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover;background-size: cover; min-width: 100%; min-height: 100%; 	
	@media (max-width: 600px) { 	background-attachment: scroll; 	} 
	@media (max-width: @iphone-screen) {
        background-attachment: scroll;
    }
	} 	
	<?php }
	
	if ($bar_sup == "select-two" && empty( $footer ) ) {?>
	#nextpage{padding:30px 0 120px 0;}	
	<?php } if ($bar_sup == "select-two") { ?>#up{bottom:70px;} 
	<?php } if( !empty( $top_bar) ) { ?>	
	<?php if ($top_bar == "select-one") { ?> .navbar{background: 
	<?php echo $meta_color; ?>;color:#FFFFFF!important;} #side_nav{border-color: #FFFFFF;} #barre{opacity:0.7;} .navbar a{color:#FFFFFF!important;} .togglenav,#show.open{background:<?php echo $meta_color; ?>;border:1px solid #FFFFFF;color: #FFFFFF;}	
	<?php	} elseif ($top_bar == "select-two") { ?> 
	.navbar{background: #FFFFFF;color:<?php echo $meta_color; ?>;} .navbar a{color:<?php echo $meta_color; ?>;} .togglenav,#show.open{background:#FFFFFF;border:1px solid <?php echo $meta_color; ?>;color: <?php echo $meta_color; ?>;} .navbar-fixed-bottom{border-top: 1px solid <?php echo $meta_color; ?>;} .navbar-fixed-top{border-bottom: 1px solid <?php echo $meta_color; ?>;} #side_nav{border-color: transparent;}	
	<?php	} elseif ($top_bar == "select-three") { ?> .navbar{background: #000000;color:#FFFFFF;} .togglenav,#show.open{background:#000000;border:1px solid <?php echo $meta_color; ?>;color: <?php echo $meta_color; ?>;} .navbar a{color:#FFFFFF!important;} #side_nav{border-color: transparent;}	
	<?php	} 	} 
	if( !empty( $meta_quote) ) {  
	if ($meta_quote == "select-one") { ?> 
	.content blockquote{border:0px;border-left:4px solid;}	
	<?php } elseif ($meta_quote == "select-two") { ?> 
	.content blockquote{border:0px;border-right:4px solid;}	
	<?php } elseif ($meta_quote == "select-three") { ?> 
	.content blockquote{border:0px;border-bottom:4px solid;padding-bottom:20px;}	
	<?php } elseif ($meta_quote == "select-four") { ?> 
	.content blockquote{border-width:2px!important;margin-left: 0px;}	
	<?php }	} 
	
	if( !empty( $meta_color ) ) { ?>
	.page_loader,#side_nav,.carousel-indicators{background:<?php echo $meta_color; ?>;} .jumbotron{background:<?php echo $meta_color; ?>;} a, a:link, a:visited, a:active, a:focus,#up, a.navbar-brand:nth-child(2):hover, .left:hover,.right:hover, .comment-notes,input#submit:hover,.mejs-currenttime, .mejs-duration{color: <?php echo $meta_color; ?>;} input#submit:hover {background: <?php echo $meta_color; ?>!important;color:#FFFFFF;} #barre, #side_nav,.carousel-indicators,.chapitre, .mejs-embed, .mejs-embed body, .mejs-container .mejs-controls, .mejs-controls .mejs-time-rail .mejs-time-total, .mejs-horizontal-volume-current, .mejs-controls .mejs-time-rail .mejs-time-current, .mejs-volume-handle, .mejs-horizontal-volume-total,.mejs-time-loaded {background: <?php echo $meta_color; ?>;} #show.open,.togglenav:hover,.togglenav:active,.togglenav:focus{background: <?php echo $meta_color; ?>;color:#FFFFFF;} #nextpage, .intro-effect-jam3.modify .header h1,.intro-effect-jam3.modify .subline{color: <?php echo $meta_color; ?>;} .btn,input#submit:hover,.btn-succes{margin:0 auto;background: <?php echo $meta_color; ?>;color:#FFFFFF;} .btn:hover,.btn-succes:hover{border:1px solid <?php echo $meta_color; ?>;color:<?php echo $meta_color; ?>;background:#FFFFFF;}	
	
	<?php if ( $meta_trigger == 'select-one' || $meta_trigger == 'select-four' || $meta_trigger == 'select-five' ) { ?> 
	button.trigger {position: fixed;background: transparent;bottom: 60px;width: 20%;left: 40%;z-index: 8000; display: block;padding: 8px 22px;border: 1px solid #FFFFFF;font-size: 1.2em;cursor: pointer;margin: 0 auto;color:#FFFFFF;} button.trigger:hover{border: 1px solid <?php echo $meta_color; ?>!important;color: <?php echo $meta_color; ?>;} 
	<?php if (!empty ($top_title) ) { 
	if ($top_title == "select-two") { ?> button.trigger {border: 1px solid #000000; color:#000000;}  	
	<?php } } 
	} else { ?> 
	button.trigger{color: <?php echo $meta_color; ?>;} button.trigger:hover{opacity: 0.7;}	
	
	<?php } } if ( $meta_quote_design == 'select-one' ) { ?> 
	.content blockquote {border-color:<?php echo $meta_color; ?>;}	
	<?php } elseif ( $meta_quote_design == 'select-two' ) { ?> 
	.content blockquote {border-color:<?php echo $meta_color; ?>;border-style:dotted;}	
	<?php } elseif ( $meta_quote_design == 'select-four' ) { ?>	
	.content blockquote {border-style:dotted;}	
	<?php } else { ?> 
	.content blockquote{border-color:#EEEEEE;}	
	<?php } 
	
	if ( $reseaux == 'select-one' ) { ?> 
	.right-net a .fa {color:<?php echo $meta_color; ?>;} 
	<?php } elseif ( $reseaux == 'select-two' ) { ?> 
	.right-net a .fa {background:<?php echo $meta_color; ?>;color:#FFFFFF;}	
	<?php } elseif ( $reseaux == 'select-three' ) { ?>	
	.right-net a .fa {color:#FFFFFF;} .fa-twitter {background: #2CA8D2;} .fa-facebook {background: #305891;}	.fa-google-plus {background: #CE4D39;}	.fa-linkedin {background: #4498C8;}	.fa-envelope-o {background: #787878;} 
	<?php } elseif ( $reseaux == 'select-three' ) { ?> 
	.right-net a .fa {color:#FFFFFF;} 
	<?php } 
	
	if( !empty( $custom_css ) ) { echo $custom_css; }
		if( !empty( $meta_color ) ) { ?>
		  .dropcap {color:<?php echo $meta_color; ?>}
		<?php } ?>
		
		.content a{color: <?php echo $meta_color; ?>;}
		.content a:hover{color<?php echo $meta_colorb; ?>}
			@media screen and (max-width: 550px) {
				.intro-effect-jam3:not(.notrans) .header h1 
				{font-size: 2.7em;margin: 0px auto;}
				.title {padding: 0 2%;top: 20%;}
				.bloc_title_top {line-height: 190%;color: #FFFFFF;padding: 10px;}
				#bloc_title_1,#bloc_title_2,#bloc_title_3,#bloc_title_4,#bloc_title_5 
				{padding: 10px;line-height: 210%;}
			}
			@media screen and (max-width: 450px) {
				.title {padding: 0 2%;top: 10%;}
				.intro-effect-jam3:not(.notrans) .header h1 {font-size: 2.5em;}
			}
			@media screen and (max-width: 350px) {
				.title {padding: 0 2%;top: 40px;}
			}

	</style>