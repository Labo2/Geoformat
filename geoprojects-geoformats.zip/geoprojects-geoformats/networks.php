<div id="networks">
	<?php 
	$gp_options = get_option( 'gp_options' ); 
	$email = $gp_options['email_share'];
	$twitter = $gp_options['twitter_share'];
	$twitter_id = $gp_options['twitter_id'];
	$facebook = $gp_options['facebook_share'];
	$googleplus = $gp_options['googleplus_share'];
	$linkedin = $gp_options['linkedin_share'];
	
	if( !empty( $email ) ) { ?>	
	<a title="<?php _e('Share by e-mail', 'simplelongform'); ?>" href="mailto:?subject=<?php _e('A friend wants to share this article with you:', 'simplelongform'); ?> <?php the_title(); ?>&amp;body=<?php _e('Read:', 'simplelongform'); ?> <strong><?php the_title(); ?></strong>&nbsp;:&nbsp;<a href=<?php the_permalink() ?>><?php the_permalink() ?></a>" rel="nofollow">
		<span class="fa fa-envelope-o fa-lg"> </span>
			<span class="screen-reader-text"><?php _e('Share by e-mail', 'simplelongform'); ?></span>
	</a>					
	<?php } ?> 

	<?php if( !empty( $twitter ) ) { ?>	
	<a target="_blank" href="http://twitter.com/home?status=<?php the_title(); ?>+<?php the_permalink();  echo " via ";  echo $twitter_id;?>"> 
		<span class="fa fa-twitter fa-lg"> </span>
			<span class="screen-reader-text"><?php _e('Share on Twitter', 'simplelongform'); ?></span>
	</a>
	<?php } ?> 

	<?php  if( !empty( $facebook ) ) { ?>	
	<a href="http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&t=<?php the_title(); ?>" target="blank"><span class="fa fa-facebook fa-lg" title="<?php _e('Share on Facebook', 'simplelongform'); ?>"> </span>
		<span class="screen-reader-text"><?php _e('Share on Facebook', 'simplelongform'); ?></span>
	</a>
	<?php } ?> 

	<?php if( !empty( $linkedin ) ) { ?>	
	<a target="_blank" href="https://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink(); ?>&title=<?php the_title(); ?>&summary=&source=<?php get_home_url(); ?>" title="<?php _e('Share on LinkedIn', 'simplelongform'); ?>">
		<span class="fa fa-linkedin fa-lg"> </span> 
			<span class="screen-reader-text"><?php _e('Share on LinkedIn', 'simplelongform'); ?></span></a>
	<?php } ?> 

	<?php if( !empty( $googleplus ) ) { ?>	
	<a target="_blank" href="https://plus.google.com/share?url=<?php the_permalink(); ?>" title="<?php _e('Share on Google+', 'simplelongform'); ?>"> 
		<span class="fa fa-google-plus fa-lg"> </span>
			<span class="screen-reader-text"><?php _e('Share on Google+', 'simplelongform'); ?></span>
	</a>
	<?php } ?> 
</div>