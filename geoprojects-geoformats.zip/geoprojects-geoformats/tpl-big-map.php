<?php
/**
 * Template Name: Big Map
 * 
 * @package GeoProjects
 */

get_header(); ?>

<div id="primary" class="content-area">
	<div id="content" class="site-content" role="main">

		<?php while ( have_posts() ) : the_post(); ?>

			<article id="big-map-page" class="hentry">
				
				<header class="entry-header">
					<h1 class="entry-title"><?php the_title(); ?></h1>
				</header>

				<?php
				$content = get_the_content();
				$content = apply_filters('the_content', $content);
				$content = str_replace(']]>', ']]&gt;', $content);

				if ( $content != '' ) : ?>
					<div class="entry-content">
						<?php the_content(); ?>
					</div>
				<?php endif; ?>

				<?php
				// Load Leaflet
				 gp_load_frontend_leaflet();
			     $map_tiles_provider = GP_DEFAULT_TILES_PROVIDER;
				?>

				<div class="gp-leaflet-map-container">
			        <div class="gp-leaflet-map-wrap">
			            <div id="gp-big-map" class="gp-leaflet-map"
			            	data-map-id="all"
			            	data-map-tiles="<?php echo $map_tiles_provider; ?>"
			            	data-map-clusterize="1"></div>
			        </div>
			    </div>
			<?php get_template_part('networks'); ?>
			</article>

		<?php endwhile; ?>

	</div>
</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
