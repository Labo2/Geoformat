<?php
/*
Single page for Geoformat
*/
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head>
	<meta name="msapplication-config" content="none"/>
	<meta charset="utf-8" />
	<title><?php bloginfo('name'); ?> <?php wp_title('-'); ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta name="robots" content="all" />
	<meta name="revisit-After" content="1 day" />
	<?php $gp_options = get_option( 'gp_options' ); $favicon = $gp_options['favicon']; 
		if (!empty($favicon) ){ ?>
		<link rel="shortcut icon" href="<?php echo $favicon; ?>">
		<?php } else{
			echo '<link rel="shortcut icon" href="'.get_template_directory_uri().'/images/favicon.ico" />';
		} ?>
	<?php wp_head(); 
	 include_once('header-geoformat.php'); ?>
		<script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js'></script>
	
</head>
<body id="top" data-spy="scroll" data-target="#side_nav">
	<div class="page_loader"> 
		<div id="inner"> 
			<h1><?php the_title(); ?> </h1>
			<p id="load_p">
				<?php if( $load_auteur == 'select-one' ) { 
					_e('by', 'lang_geoprojects'); ?> <strong> 
					<?php echo $meta_auteur; ?> </strong>
				<?php } ?>
			</p>
		
			<?php if( $meta_loader == "select-two" ) {
				 $back = plugin_dir_url( __FILE__ ) . '../css/ajax-loader.gif'; ?>
				<br/>
				<img src="<?php echo $back ?>" alt="<?php _e('Loading', 'lang_geoprojects'); ?>" />
			<?php } elseif ( $meta_loader == "select-three" ) { ?>
				<canvas class="loader"></canvas>
			<?php } ?>
	</div>

	</div>
<!--Content-->
	<div id="progression">
		<div id="barre"></div>
	</div>

<nav class="navbar <?php if ($bar_sup == "select-two") { ?>navbar-fixed-bottom<?php } else { ?>navbar-fixed-top<?php } ?>">
    <div class="col-md-12">
        <div class="navbar-header">
			<button class="togglenav" id="show">
            <span class="glyphicon glyphicon-menu-hamburger"></span>
			</button>
			<a class="navbar-brand"  href="<?php echo get_site_url(); ?>"><?php bloginfo("name") ?></a>
			<a class="navbar-brand" id="home" href="<?php echo get_site_url(); ?>" target="_blank"><span class="glyphicon glyphicon-home"></span></a>
			  <?php if ( $bar_title == 'select-one' ) { ?>
				  <div id="top_title">
				  <?php the_title(); ?>
				  </div>
			  <?php } else { }?>
		</div>
		
		<div class="navbar-right right-net">
			<?php get_template_part('networks'); ?>
		</div>
	</div>
</nav>

<?php if ( $burger == "select-one" ) { ?>	
<nav id="side_nav" class="nav_titles <?php if ($bar_sup == "select-one") {?>burger_top<?php } else {?>burger_bottom<?php } ?>">
	<ul id="side_nav_container" class="nav" role="tablist">
		<li>
			<a href="#top"  class="scrollTo"><span class="fa fa-angle-right"></span> <?php _e('Home', 'lang_geoprojects'); ?></a>
		</li>		
			<?php if( !empty( $section_title_un ) ) { ?> 
		<li>
			<a href="#section_un" class="scrollTo"><span class="fa fa-angle-right"></span> <?php echo $section_title_un; ?></a>
		</li>
			<?php } if( !empty( $section_title_deux ) ) { ?> 
		<li>
			<a href="#section_deux" class="scrollTo"><span class="fa fa-angle-right"></span>  <?php echo $section_title_deux; ?></a>
		</li>
			<?php } if( !empty( $section_title_trois ) ) { ?> 
		<li>
			<a href="#section_trois" class="scrollTo"><span class="fa fa-angle-right"></span> <?php echo $section_title_trois; ?></a>
		</li>
			<?php } if( !empty( $section_title_quatre ) ) { ?> 
		<li>
			<a href="#section_quatre" class="scrollTo"><span class="fa fa-angle-right"></span>  <?php echo $section_title_quatre; ?></a>
		</li>
			<?php } if( !empty( $section_title_cinq ) ) { ?> 
		<li>
			<a href="#section_cinq" class="scrollTo"><span class="fa fa-angle-right"></span> <?php echo $section_title_cinq; ?> </a>
		</li>
			
			<?php } ?> 
	</ul>
</nav>
<?php } elseif ($burger == "select-two") { ?>	
		<nav id="side_nav" class="nav_circles <?php if ($bar_sup == "select-one") {?>burger_top<?php } else {?>burger_bottom<?php } ?>">
			<ul id="navtop" class="nav" role="tablist">
				<li>
					<a href="#top" data-toggle="tooltip" title="<?php _e('Home', 'lang_geoprojects'); ?>" class="scrollTo"><span class="fa fa-circle"></span> </a>
				</li>
				<?php if( !empty( $section_un ) ) { ?> 
				<li>
					<a href="#section_un" data-toggle="tooltip" title="<?php echo $section_title_un; ?>" class="scrollTo"><span class="fa fa-circle"></span></a>
				</li>
				<?php } ?> 
				
				<?php if( !empty( $section_deux ) ) { ?> 
				<li>
					<a href="#section_deux" data-toggle="tooltip" title="<?php echo $section_title_deux; ?>" class="scrollTo"><span class="fa fa-circle"></span></a>
				</li>
				<?php } ?> 
				
				<?php if( !empty( $section_trois ) ) { ?> 
				<li>
					<a href="#section_trois" data-toggle="tooltip" title="<?php echo $section_title_trois; ?>" class="scrollTo"> <span class="fa fa-circle"></span> </a>
				</li>
				<?php } ?> 
				
				<?php if( !empty( $section_quatre ) ) { ?> 
				<li>
					<a href="#section_quatre" data-toggle="tooltip" title="<?php echo $section_title_quatre; ?>" class="scrollTo"> <span class="fa fa-circle"></span> </a>
				</li>
				<?php } ?> 
				
				<?php if( !empty( $section_cinq ) ) { ?> 
				<li>
					<a href="#section_cinq" data-toggle="tooltip" title="<?php echo $section_title_cinq; ?>" class="scrollTo"> <span class="fa fa-circle"></span> </a>
				</li>
				<?php } ?> 
				 
			</ul>
		</nav>
<?php } ?>

<div id="container" class="<?php if ( $intro == 'select-one' ) { ?>intro-effect-push container<?php } elseif ( $intro == 'select-two' ) { ?>intro-effect-jam3<?php } else { ?>intro-effect-push container<?php } ?>">
	<header class="header">	
		<div class="bg-img">
		<?php if( !empty( $meta_top ) ) { ?>	
		</div>
			<div class="title title_home col-md-10 col-sm-10">	
				<h1><span class="bloc_title_top"><?php the_title(); ?></span></h1>
			</div>
		
			<?php } 
			elseif(!((get_post_meta($post->ID, 'meta-video', TRUE))=='')) {  
			$meta_video = get_post_meta( get_the_ID(), 'meta-video',true );
					if( !empty( $meta_video ) ) {
					echo html_entity_decode($meta_video); } ?>
			</div>
			<div class="title_bg_une <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-10<?php } ?>">
				<h1 class="videott"><span class="bloc_title_top"><?php the_title(); ?></span></h1>
			</div>

			<?php } 
			elseif(!((get_post_meta($post->ID, 'meta-map', TRUE))=='')) {  
			$meta_map = get_post_meta( get_the_ID(), 'meta-map',true );
					if( !empty( $meta_map ) ) {
					echo html_entity_decode($meta_map); } ?>
			</div>
			<div class="title <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-10<?php } ?>">
				<h1><span class="bloc_title_top_map"><?php the_title(); ?></span></h1>
			</div>

			<?php } 
			
			
			else { ?>
				<div class="title <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-10<?php } ?>">	
					<h1><span class="bloc_title_top"><?php the_title(); ?></span></h1>
				</div>
			</div>
			<?php }	if ( $intro == 'select-three' ) { ?>
				<div class="bg-img"></div>
			<?php } ?>
	</header>
		<div class="clear"> </div>
		<button class="trigger"><?php if ( $meta_trigger == 'select-three' || $meta_trigger == 'select-four' ) { ?>
			<span class="fa fa-angle-down"></span>
			<?php } elseif ( $meta_trigger == 'select-two' || $meta_trigger == 'select-five' ) {  ?>
			<span class="glyphicon glyphicon-chevron-down"></span>
			<?php } elseif ( $meta_trigger == 'select-one' ) { ?>
			<span><?php echo $trigger_text; ?></span>
			<?php } ?></button>			
</div>

<!--Container -->
<?php include_once('content-geoformat.php'); ?>		

<!--Modal-->
<div id="slf_modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">×</button>
			</div>
			
			<div class="modal-body">						
				<p class="modal-body-text">   </p>
			</div>
			
			<div class="modal-footer">								
				<button class="btn btn-default btnmodal" data-dismiss="modal"><?php _e('Close', 'lang_geoprojects') ?></button>
			</div>
		</div>
	</div>
</div>

<?php if( !empty( $footer ) ) { ?> 
		<footer>
			<div id="footer_lf" class="container col-md-12"> <?php
				echo apply_filters('the_content', $footer);
			?> </div> 
		</footer> 
	<?php } ?> 	

	<div id="up">
		<a href="#top" class="toptop">
		<?php if ( $meta_trigger == 'select-three' || $meta_trigger == 'select-four' ) { ?>
		<span class="fa fa-angle-up"></span>
			<?php } else { ?>
		<span class="glyphicon glyphicon-chevron-up"></span>
		<?php } ?>
		</a>
	</div>

<!--Footer-->
	
		
		<?php if ( $meta_loader_animate == 'select-one' ) { ?>
		<script type="text/javascript">
			$(window).load(function() {$(".page_loader").fadeOut("slow").animate({top:-1600},1200);})
		</script> <?php } else { ?>
					<script type="text/javascript">
						$(window).load(function() {$(".page_loader").animate({top:-1600},1200);})
					</script>
				 <?php } ?>

	<?php $gp_options = get_option( 'gp_options' ); $google_anaytics = $gp_options['google_analytics'];
		if (!empty($google_anaytics) ){
			echo $google_anaytics;
		}
	
	wp_footer(); ?>
</body>
</html>