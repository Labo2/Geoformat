<?php
/**
 * The template for displaying Search Results pages.
 *
 * @package GeoProjects
 */

get_header(); ?>

		
			<div id="content" class="site-content" role="main">

			<?php if ( have_posts() ) : ?>


				<?php gp_content_nav( 'nav-above' ); ?>

				<?php /* Start the Loop */ ?>
				
					<section id="primary" class="content-area">
						<div id="content" class="site-content" role="main">
						
							<header class="page-header">
								<h1 class="page-title results txt-on-bg"><?php echo $wp_query->found_posts; ?> 
								<?php printf( _n( 'search result for: %s', 'search results for: %s', 'lang_geoprojects' ), '<span>' . get_search_query() . '</span>' ); ?></h1>
							</header>
						
						<?php while ( have_posts() ) : the_post(); 
								get_template_part( 'content', 'search' );  
							  endwhile; ?>
						
						</div>
					</section>
				
				<?php get_sidebar();  
				
				gp_content_nav( 'nav-below' ); 

				else : 

				get_template_part( 'no-results', 'search' ); ?>

			<?php endif; ?>

			</div>
		

		<?php get_footer(); ?>