jQuery('document').ready(function($){

var commentform=$('#commentform'); 
commentform.prepend('<div id="comment-status" ></div>'); 
var statusdiv=$('#comment-status'); 

commentform.submit(function(){
var formdata=commentform.serialize();
statusdiv.html('<p> <?php _e('Loading','lang_geoprojects'); ?> </p>');
var formurl=commentform.attr('action');

$.ajax({
type: 'post',
url: formurl,
data: formdata,
error: function(XMLHttpRequest, textStatus, errorThrown){
statusdiv.html('<p class="wdpajax-error" > <?php _e('Error','lang_geoprojects'); ?> </p>');
},
success: function(data, textStatus){
if(data=="success")
statusdiv.html('<p class="ajax-success" > <?php _e('Your comment has been sent','lang_geoprojects'); ?> </p>');
else
statusdiv.html('<p class="ajax-error" > <?php _e('Please wait before posting a comment','lang_geoprojects'); ?> </p>');
commentform.find('textarea[name=comment]').val('');
},
});
return false;

});
});