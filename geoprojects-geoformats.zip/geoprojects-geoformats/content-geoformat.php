<!--Intro-->
<article class="content <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-10<?php } ?> intro" >

<h1 id="topscroll"><?php the_title(); ?></h1>

<?php if( !empty( $meta_auteur ) ) { ?>
		<div id="author">
			<?php _e('by', 'lang_geoprojects'); ?> 
			<strong> <?php echo $meta_auteur; ?></strong>
		</div>	
<?php } 

	if( !empty( $meta_photos ) ) { ?> 
	<div id="photos"> 
		<?php _e('Pictures: ', 'lang_geoprojects'); ?>  
		<strong><?php echo $meta_photos; ?> </strong> 
	</div> 
		
		<?php }  if ($meta_date == "select-one") { ?>
			<div id="date">
				<?php the_time(__('F j, Y','lang_geoprojects')); ?>
			</div>	
		<?php } ?>

<?php if( !empty( $subline ) ) { ?> 		
	<div class="subline"> 
	<?php echo $subline; ?> 
	</div> <?php } ?> 
<?php if( !empty( $chapo ) ) { ?> 		
	<div id="chapo"> 
	<?php echo apply_filters('the_content', $chapo); ?> 
	</div> <?php } ?> 
<?php if( !empty( $txt ) ) { ?> 
	<div class="intro_text" >
	<?php echo apply_filters('the_content', $txt); ?> 
	</div> 
	<?php } ?>
<!--1-->
<?php if( !empty( $section_img_1 ) ) { ?> 
	</article>		

	<div id="section_un" class="chapitre">
		<?php if( !empty( $section_title_un ) ) { ?>
			<div class="section_title" id="sec1_title">
				<span id="bloc_title_1"><?php echo $section_title_un; ?></span>
			</div> <?php } ?> 
	</div>
	
	<?php if( !empty( $section1_caption ) ) { ?> 
	<div class="caption_img_slf"> 
		<?php echo $section1_caption; ?> 
	</div> <?php } ?> 
	<article class="content <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-10<?php } ?>" > 
	
	<?php } 
	
	elseif( !empty( $section_video_1 ) ) { ?>
	</article>
	<div class="chapitre" id="section_un">	
			<div class="bg_container">
				<?php echo html_entity_decode($section_video_1); ?>
			</div>
		<?php if( !empty( $section_title_un ) ) { ?>
			<div class="video_title" id="sec1_title">
				<span id="bloc_title_1"><?php echo $section_title_un; ?></span>
			</div>
		<?php } ?> 
	</div>
	<?php 
		if( !empty( $section1_caption ) ) { ?> 
			<div class="caption_img_slf"> <?php
				echo $section1_caption; ?> 
			</div> 
		<?php } ?> 
	<article class="content <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-10<?php } ?>" >				
	<?php }  
	
	elseif( !empty( $section_map_1 ) ) { ?>
	</article>
	<div class="chapitre" id="section_un">	
			<div class="bg_container">
				<?php echo html_entity_decode($section_map_1); ?>
			</div>
		<?php if( !empty( $section_title_un ) ) { ?>
			<div class="map_title" id="sec1_title">
				<span id="bloc_title_1"><?php echo $section_title_un; ?></span>
			</div>
		<?php } ?> 
	</div>
	<?php 
		if( !empty( $section1_caption ) ) { ?> 
			<div class="caption_img_slf"> <?php
				echo $section1_caption; ?> 
			</div> 
		<?php } ?> 
	<article class="content <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-10<?php } ?>" >				
	<?php }  
	
	else { echo ""; } ?> 
	<?php if( !empty( $section_un ) ) { ?> 
		<section id="first"> 
		<?php echo apply_filters('the_content', $section_un); ?>
		</section>
		<div class="clear"> </div>
<?php } ?>
<!--2-->	
<?php if( !empty( $section_img_2 ) ) { ?> 
	</article>		

	<div id="section_deux" class="chapitre">
		<?php if( !empty( $section_title_deux ) ) { ?>
			<div class="section_title" id="sec2_title">
				<span id="bloc_title_2"><?php echo $section_title_deux; ?></span>
			</div> <?php } ?> 
	</div>
	<?php if( !empty( $section2_caption ) ) { ?> 
	<div class="caption_img_slf"> 
		<?php echo $section2_caption; ?> 
	</div> <?php } ?> 
	<article class="content <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-10<?php } ?>" > 
	<?php } 
	
	elseif(!empty ($section_video_2)) { ?>
	
	</article>
	<div class="chapitre" id="section_deux">	
			<div class="bg_container">
				<?php echo html_entity_decode($section_video_2); ?>
			</div>
		<?php if( !empty( $section_title_deux ) ) { ?>
			<div class="video_title" id="sec2_title">
				<span id="bloc_title_2"><?php echo $section_title_deux; ?></span>
			</div>
		<?php } ?> 
	</div>
	<?php 
		if( !empty( $section2_caption ) ) { ?> 
			<div class="caption_img_slf"> <?php
				echo $section2_caption; ?> 
			</div> 
		<?php } ?> 
	<article class="content <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-10<?php } ?>" >				
	<?php }  
	
	elseif( !empty( $section_map_2 ) ) { ?>
	</article>
	<div class="chapitre" id="section_deux">	
			<div class="bg_container">
				<?php echo html_entity_decode($section_map_2); ?>
			</div>
		<?php if( !empty( $section_title_deux ) ) { ?>
			<div class="map_title" id="sec2_title">
				<span id="bloc_title_2"><?php echo $section_title_deux; ?></span>
			</div>
		<?php } ?> 
	</div>
	<?php 
		if( !empty( $section2_caption ) ) { ?> 
			<div class="caption_img_slf"> <?php
				echo $section2_caption; ?> 
			</div> 
		<?php } ?> 
	<article class="content <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-20<?php } ?>" >				
	<?php }  
	
	else { echo ""; } ?> 
	<?php if( !empty( $section_deux ) ) { ?> 
		<section id="first"> 
		<?php echo apply_filters('the_content', $section_deux); ?>
		</section>
		<div class="clear"> </div>
<?php } ?>
<!--3-->
<?php if( !empty( $section_img_3 ) ) { ?> 
</article>		

	<div id="section_trois" class="chapitre">
		<?php 
		if( !empty( $section_title_trois ) ) { ?>
			<div class="section_title" id="sec3_title">
				<span id="bloc_title_3"><?php echo $section_title_trois; ?></span>
			</div> <?php } ?> 
	</div>
	<?php if( !empty( $section3_caption ) ) { ?> 
	<div class="caption_img_slf"> 
		<?php echo $section3_caption; ?> 
	</div> <?php } ?> 
	<article class="content <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-10<?php } ?>" > 
	<?php } 
	
	elseif(!empty($section_video_3)) {  ?>
		
	</article>
	<div class="chapitre" id="section_trois">	
			<div class="bg_container">
				<?php echo html_entity_decode($section_video_3); ?>
			</div>
		<?php if( !empty( $section_title_trois ) ) { ?>
			<div class="video_title" id="sec3_title">
				<span id="bloc_title_3"><?php echo $section_title_trois; ?></span>
			</div>
		<?php } ?> 
	</div>
	<?php 
		if( !empty( $section3_caption ) ) { ?> 
			<div class="caption_img_slf"> <?php
				echo $section3_caption; ?> 
			</div> 
		<?php } ?> 
	<article class="content <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-10<?php } ?>" >				
	<?php }  
	
	elseif( !empty( $section_map_3 ) ) { ?>
	</article>
	<div class="chapitre" id="section_trois">	
			<div class="bg_container">
				<?php echo html_entity_decode($section_map_3); ?>
			</div>
		<?php if( !empty( $section_title_trois ) ) { ?>
			<div class="map_title" id="sec3_title">
				<span id="bloc_title_3"><?php echo $section_title_trois; ?></span>
			</div>
		<?php } ?> 
	</div>
	<?php 
		if( !empty( $section3_caption ) ) { ?> 
			<div class="caption_img_slf"> <?php
				echo $section3_caption; ?> 
			</div> 
		<?php } ?> 
	<article class="content <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-30<?php } ?>" >				
	<?php }  
	
	else { echo ""; } ?> 
	<?php if( !empty( $section_trois ) ) { ?> 
		<section id="first"> 
		<?php echo apply_filters('the_content', $section_trois); ?>
		</section>
		<div class="clear"> </div>
<?php } ?>			
<!--4-->
	<?php if( !empty( $section_img_4 ) ) { ?> 
	</article>		

	<div id="section_quatre" class="chapitre">
		<?php if( !empty( $section_title_quatre ) ) { ?>
			<div class="section_title" id="sec4_title">
				<span id="bloc_title_4"><?php echo $section_title_quatre; ?></span>
			</div> <?php } ?> 
	</div>
	<?php if( !empty( $section4_caption ) ) { ?> 
	<div class="caption_img_slf"> 
		<?php echo $section4_caption; ?> 
	</div> <?php } ?> 
	<article class="content <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-10<?php } ?>" > 
	<?php } 
	
	elseif(!empty($section_video_4)) {  ?>
	
	</article>
	<div class="chapitre" id="section_quatre">	
			<div class="bg_container">
				<?php echo html_entity_decode($section_video_4); ?>
			</div>
		<?php if( !empty( $section_title_quatre ) ) { ?>
			<div class="video_title" id="sec4_title">
				<span id="bloc_title_4"><?php echo $section_title_quatre; ?></span>
			</div>
		<?php } ?> 
	</div>
	<?php 
		if( !empty( $section4_caption ) ) { ?> 
			<div class="caption_img_slf"> <?php
				echo $section4_caption; ?> 
			</div> 
		<?php } ?> 
	<article class="content <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-10<?php } ?>" >				
	<?php }  
	
	
	elseif( !empty( $section_map_4 ) ) { ?>
	</article>
	<div class="chapitre" id="section_quatre">	
			<div class="bg_container">
				<?php echo html_entity_decode($section_map_4); ?>
			</div>
		<?php if( !empty( $section_title_quatre ) ) { ?>
			<div class="map_title" id="sec4_title">
				<span id="bloc_title_4"><?php echo $section_title_quatre; ?></span>
			</div>
		<?php } ?> 
	</div>
	<?php 
		if( !empty( $section4_caption ) ) { ?> 
			<div class="caption_img_slf"> <?php
				echo $section4_caption; ?> 
			</div> 
		<?php } ?> 
	<article class="content <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-40<?php } ?>" >				
	<?php }  
	
	else { echo ""; } ?> 
	<?php $section_quatre = get_post_meta( get_the_ID(), '_wp_editor_section_4', true );
		if( !empty( $section_quatre ) ) { ?> 
		<section id="first"> 
		<?php echo apply_filters('the_content', $section_quatre); ?>
		</section>
		<div class="clear"> </div>
<?php } ?>
<!--5-->
<?php if( !empty( $section_img_5 ) ) { ?> 
	</article>		

	<div id="section_cinq" class="chapitre">
		<?php if( !empty( $section_title_cinq ) ) { ?>
			<div class="section_title" id="sec5_title">
				<span id="bloc_title_5"><?php echo $section_title_cinq; ?></span>
			</div> <?php } ?> 
	</div>
	<?php if( !empty( $section5_caption ) ) { ?> 
	<div class="caption_img_slf"> 
		<?php echo $section5_caption; ?> 
	</div> <?php } ?> 
	<article class="content <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-10<?php } ?>" > 
	<?php } 
	
	elseif(!empty($section_video_5)) {  ?>
	
</article>
	<div class="chapitre" id="section_cinq">	
			<div class="bg_container">
				<?php echo html_entity_decode($section_video_5); ?>
			</div>
		<?php if( !empty( $section_title_cinq ) ) { ?>
			<div class="video_title" id="sec5_title">
				<span id="bloc_title_5"><?php echo $section_title_cinq; ?></span>
			</div>
		<?php } ?> 
	</div>
	<?php 
		if( !empty( $section5_caption ) ) { ?> 
			<div class="caption_img_slf"> <?php
				echo $section5_caption; ?> 
			</div> 
		<?php } ?> 
	<article class="content <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-10<?php } ?>" >				
	<?php }  
	
	elseif( !empty( $section_map_5 ) ) { ?>
	</article>
	<div class="chapitre" id="section_cinq">	
			<div class="bg_container">
				<?php echo html_entity_decode($section_map_5); ?>
			</div>
		<?php if( !empty( $section_title_cinq ) ) { ?>
			<div class="map_title" id="sec5_title">
				<span id="bloc_title_5"><?php echo $section_title_cinq; ?></span>
			</div>
		<?php } ?> 
	</div>
	<?php 
		if( !empty( $section5_caption ) ) { ?> 
			<div class="caption_img_slf"> <?php
				echo $section5_caption; ?> 
			</div> 
		<?php } ?> 
	<article class="content <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-50<?php } ?>" >				
	<?php }  
	
	else { echo ""; } ?> 
	<?php if( !empty( $section_cinq ) ) { ?> 
		<section id="first"> 
		<?php echo apply_filters('the_content', $section_cinq); ?>
		</section>
		<div class="clear"> </div>
<?php } ?>
<!--6-->
<?php if( !empty( $section_img_6 ) ) { ?> 
	</article>		

	<div id="section_six" class="chapitre">
		<?php if( !empty( $section_title_six ) ) { ?>
			<div class="section_title" id="sec6_title">
				<span id="bloc_title_6"><?php echo $section_title_six; ?></span>
			</div> <?php } ?> 
	</div>
	<?php if( !empty( $section6_caption ) ) { ?> 
	<div class="caption_img_slf"> 
		<?php echo $section6_caption; ?> 
	</div> <?php } ?> 
	<article class="content <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-10<?php } ?>" > 
	<?php } elseif(!empty($section_video_6)) {  ?>
	
</article>
	<div class="chapitre" id="section_six">	
			<div class="bg_container">
				<?php echo html_entity_decode($section_video_6); ?>
			</div>
		<?php if( !empty( $section_title_six ) ) { ?>
			<div class="video_title" id="sec6_title">
				<span id="bloc_title_6"><?php echo $section_title_six; ?></span>
			</div>
		<?php } ?> 
	</div>
	<?php 
		if( !empty( $section6_caption ) ) { ?> 
			<div class="caption_img_slf"> <?php
				echo $section6_caption; ?> 
			</div> 
		<?php } ?> 
	<article class="content <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-10<?php } ?>" >				
	<?php }  else { echo ""; } ?> 
	<?php if( !empty( $section_six ) ) { ?> 
		<section id="first"> 
		<?php echo apply_filters('the_content', $section_six); ?>
		</section>
		<div class="clear"> </div>
<?php } ?>
<!--7-->
<?php if( !empty( $section_img_7 ) ) { ?> 
	</article>		

	<div id="section_sept" class="chapitre">
		<?php if( !empty( $section_title_sept ) ) { ?>
			<div class="section_title" id="sec7_title">
				<span id="bloc_title_7"><?php echo $section_title_sept; ?></span>
			</div> <?php } ?> 
	</div>
	<?php if( !empty( $section7_caption ) ) { ?> 
	<div class="caption_img_slf"> 
		<?php echo $section7_caption; ?> 
	</div> <?php } ?> 
	<article class="content <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-10<?php } ?>" > 
	<?php } elseif(!empty($section_video_7)) {  ?>
	
</article>
	<div class="chapitre" id="section_sept">	
			<div class="bg_container">
				<?php echo html_entity_decode($section_video_7); ?>
			</div>
		<?php if( !empty( $section_title_sept ) ) { ?>
			<div class="video_title" id="sec7_title">
				<span id="bloc_title_7"><?php echo $section_title_sept; ?></span>
			</div>
		<?php } ?> 
	</div>
	<?php 
		if( !empty( $section7_caption ) ) { ?> 
			<div class="caption_img_slf"> <?php
				echo $section7_caption; ?> 
			</div> 
		<?php } ?> 
	<article class="content <?php if ($meta_col == "select-two") { echo $large; } elseif ($meta_col == "select-three") { echo $small; } else { ?>col-lg-7 col-md-7 col-sm-10<?php } ?>" >				
	<?php }  else { echo ""; } ?> 
	<?php if( !empty( $section_sept ) ) { ?> 
		<section id="first"> 
		<?php echo apply_filters('the_content', $section_sept); ?>
		</section>
		<div class="clear"> </div>
<?php } ?>	

	<?php $nextpage = get_option('nextp', array() ); 
	if( !empty( $nextpage ) ) { ?>
	<div id="nextpage"> <?php 	
		$prev_post = get_previous_post();
			if($prev_post) { ?>
			<span class="prevlf">	<?php				
			   $prev_title = strip_tags(str_replace('"', '', $prev_post->post_title)); ?>
			   <span class="fa fa-angle-left"></span><span class="fa fa-angle-left"></span> 
			  <?php echo "\t" . '<a rel="prev" href="' . get_permalink($prev_post->ID) . '" title="' . $prev_title. '" class=" ">' .  $prev_title . '</a>' . "\n";
			?> </span> <?php
			}

		$next_post = get_next_post();
			if($next_post) {  ?>
			<span class="nextlf">	<?php
			   $next_title = strip_tags(str_replace('"', '', $next_post->post_title));
			   echo "\t" . '<a rel="next" href="' . get_permalink($next_post->ID) . '" title="' . $next_title. '" class=" ">' .  $next_title . '</a> <span class="fa fa-angle-right"></span><span class="fa fa-angle-right"></span>' . "\n";
			?> </span> <?php
			} ?>
	</div>
	<div class="clear"></div>
<?php } ?> 

<!--Comments-->				
<?php if ( comments_open() || '0' != get_comments_number() ) { ?>
<section id="slf_comments">
<?php comments_template( '/comments.php', true ); ?>
</section> <?php } ?>

</article>
<div class="clear"></div>