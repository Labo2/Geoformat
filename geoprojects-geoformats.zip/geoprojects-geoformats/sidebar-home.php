<?php
/**
 * The Default Sidebar
 *
 * @package GeoProjects
 */
?>
<div id="home-maps" role="complementary">
	<h3 class="title-home">
		<?php _e( 'Last Maps', 'lang_geoprojects' ); ?>
	</h3>
	<?php 
	
	gp_home_maps();
	
	?>
	<div class="clear"></div>
	
		<h3 class="title-home geo-title">
			<?php _e( 'Last Geoformats', 'lang_geoprojects' ); ?>
		</h3>
			<div id="geoformat-home">
			<?php 
		
			gp_home_geoformat();
		
			?>
			</div>
</div>

<div class="clear"></div>