<?php
/**
 * GeoProjects Common functions
 *
 * @package GeoProjects
 */

/**
 * Require Queries functions
 */
require_once( GP_PATH_INC . '/functions-queries.php' );

/**
 * Require common utils functions
 */
require_once( GP_PATH_INC . '/functions-common-utils.php' );

/**
 * Require AJAX functions
 */
require_once( GP_PATH_INC . '/functions-ajax.php' );


/**
 * Register posts types (in init action)
 */
require_once( GP_PATH_CPT . '/projects.php' );
require_once( GP_PATH_CPT . '/maps.php' );
require_once( GP_PATH_CPT . '/markers.php' );
require_once( GP_PATH_CPT . '/geoformat.php' );

/**
 * Include Custom Widgets classes definitions
 */
require_once( GP_PATH_OTHERS . '/widget-posts-in-category.php' );

/**
 * Require JS i18n
 */
require_once( GP_PATH_INC . '/js-i18n.php' );

/**
 * Require JS global Vars
 */
require_once( GP_PATH_INC . '/js-global-vars.php' );


/**
 * Flush Rewrite Rules on theme switching
 */
function gp_flush_rewrite_rules() {
	flush_rewrite_rules();
}

add_action( 'after_switch_theme', 'gp_flush_rewrite_rules' );


/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which runs
 * before the init hook. The init hook is too late for some features, such as indicating
 * support post thumbnails.
 *
 */
function gp_setup() {

	/**
	 * Custom template tags for this theme.
	 */
	require( GP_PATH_OTHERS . '/template-tags.php' );
	/**
	 * Custom functions that act independently of the theme templates
	 */
	require( GP_PATH_OTHERS . '/extras.php' );

	/**
	 * Make theme available for translation
	 * Translations can be filed in the /languages/ directory
	 */
	load_theme_textdomain( 'lang_geoprojects', GP_PATH_LANGUAGES );

	/**
	 * Unactivate Theme Editor
	 */
	define( 'DISALLOW_FILE_EDIT', true );

	/**
	 * This theme styles the visual editor with editor-style.css to match the theme style.
	 */
	add_editor_style();

	/**
	 * Add default posts and comments RSS feed links to head
	 */
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
	) );

	/**
	 * Enable support for Post Thumbnails
	 */
	add_theme_support( 'post-thumbnails' );

	// This theme allows users to set a custom background.
	add_theme_support(
		'custom-background',
		array( 'default-color' => '2C3A4E' )
	);

	/**
	 * This theme uses wp_nav_menu() in one location.
	 */
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'lang_geoprojects' ),
	) );

	/**
	 * Add Images sizes
	 */
	add_image_size( 'gp-front-map-fimg', GP_IMAGE_SIZE_FRONT_MAP_FIMG_WIDTH, GP_IMAGE_SIZE_FRONT_MAP_FIMG_HEIGHT, true );
	add_image_size( 'gp-marker-popup', GP_IMAGE_SIZE_MARKER_POPUP_WIDTH, GP_IMAGE_SIZE_MARKER_POPUP_HEIGHT, true );
	add_image_size( 'gp-marker-popup-ribbon', GP_IMAGE_SIZE_MARKER_POPUP_RIBBON_WIDTH, GP_IMAGE_SIZE_MARKER_POPUP_RIBBON_HEIGHT, true );
	add_image_size( 'gp-project-thumb', GP_IMAGE_SIZE_PROJECT_THUMB_WIDTH, GP_IMAGE_SIZE_PROJECT_THUMB_HEIGHT, false );
	add_image_size( 'gp-post-thumb-in-list', GP_IMAGE_SIZE_POST_THUMB_IN_LIST_WIDTH, GP_IMAGE_SIZE_POST_THUMB_IN_LIST_HEIGHT, true );

	// Create/update theme options
	gp_manage_theme_options();

}

add_action( 'after_setup_theme', 'gp_setup' );

/**
*Custom Login
*/

function gp_loginCSS() {
	echo '<link rel="stylesheet" type="text/css" href="'.get_template_directory_uri().'/css/wp-login.css"/>';
}
add_action('login_head', 'gp_loginCSS');

//Favicon in back-end
function add_favicon() {
  	$gp_options = get_option( 'gp_options' );
	$favicon = $gp_options['favicon'];
	if (!empty ($favicon)){
	echo '<link rel="shortcut icon" href="' . $favicon . '" />';
	} else{
	echo '<link rel="shortcut icon" href="'.get_template_directory_uri().'/images/favicon.ico" />';
	}
}
add_action('login_head', 'add_favicon');
add_action('admin_head', 'add_favicon');

/*
*Disconnect
*/
add_action('wp_logout','gp_home');
	function gp_home(){
		wp_redirect( home_url() );
		exit();
	}

	function gp_login_logo_url() {
		return home_url();
	}
add_filter( 'login_headerurl', 'gp_login_logo_url' );

/**
 * Define the default theme options (settings)
 */
function gp_manage_theme_options() {

	$default_options = array(
		'title_color' 					=> GP_DEFAULT_TITLE_COLOR,
		'title_color' 					=> GP_DEFAULT_TITLE_COLOR,
		'title_color' 					=> GP_DEFAULT_TITLE_COLOR,
		'tagline_color' 				=> GP_DEFAULT_TAGLINE_COLOR,
		'primary_color'					=> GP_DEFAULT_PRIMARY_COLOR,
		'secondary_color'				=> GP_DEFAULT_SECONDARY_COLOR,
		'background_color'				=> GP_DEFAULT_BACKGROUND_COLOR,
		'front_nb_maps'					=> GP_DEFAULT_FRONT_NB_MAPS,
		'tiles_provider'                => GP_DEFAULT_TILES_PROVIDER,
		'special_map_tiles_provider'    => GP_DEFAULT_TILES_PROVIDER,
		'cloudmade_api_key'             => GP_DEFAULT_CLOUDMADE_API_KEY,
		'cloudmade_style'               => GP_DEFAULT_CLOUDMADE_STYLE,
		'special_map_cloudmade_style'   => GP_DEFAULT_CLOUDMADE_STYLE,
		'center_lat' 					=> GP_DEFAULT_MAP_CENTER_LAT,
		'center_lng' 					=> GP_DEFAULT_MAP_CENTER_LNG,
		'zoom'							=> GP_DEFAULT_MAP_ZOOM,
		'export_maps'					=> GP_DEFAULT_EXPORT_MAPS,
		'url_twitter' 					=> GP_DEFAULT_URL_TWITTER,
		'url_facebook' 					=> GP_DEFAULT_URL_FACEBOOK,
		'url_youtube' 					=> GP_DEFAULT_URL_YOUTUBE,
		'twitter_id' 					=> GP_DEFAULT_TWITTER_ID,
		'email_share'   				=> GP_DEFAULT_EMAIL_SHARE,
		'twitter_share'   				=> GP_DEFAULT_TWITTER_SHARE,
		'facebook_share'   				=> GP_DEFAULT_FACEBOOK_SHARE,
		'linkedin_share'   				=> GP_DEFAULT_LINKEDIN_SHARE,
		'googleplus_share'   			=> GP_DEFAULT_GOOGLEPLUS_SHARE,
		'font_text'   				    => GP_DEFAULT_FONT_TEXT,
		'font_title'   				    => GP_DEFAULT_FONT_TITLE,
		'favicon'   				    => GP_DEFAULT_FAVICON,
		'google_analytics'   			=> GP_DEFAULT_GOOGLE_ANALYTICS,
		'project_trash_keep_contents' 	=> GP_DEFAULT_PROJECT_TRASH_KEEP_CONTENTS,
		'map_trash_keep_markers'		=> GP_DEFAULT_MAP_TRASH_KEEP_MARKERS
	);

	// Get current options if any
	$current_options = get_option( 'gp_options' );
	$current_gp_theme_version = get_option( 'gp_theme_version' );

	// Options already exists
	if ( $current_options !== false ) {

		// Test if no version was set
		if ( $current_gp_theme_version === false ) {

			update_option( 'gp_theme_version', '0.1.0' );
			$current_gp_theme_version = '0.1.0';

		}

		// Need options update ?
		if ( version_compare( $current_gp_theme_version, GP_THEME_VERSION, '<' ) === true ) {

			// Update for 0.1.1
			if ( GP_THEME_VERSION == '0.1.1' ) {
				$current_options['title_color'] = GP_DEFAULT_TITLE_COLOR;
				$current_options['tagline_color'] = GP_DEFAULT_TAGLINE_COLOR;
				$current_options['background_color'] = GP_DEFAULT_BACKGROUND_COLOR;

				update_option( 'gp_options', $current_options );
				update_option( 'gp_theme_version', GP_THEME_VERSION );
			}
		}
	
	}
	// Create options
	else {

		add_option( 'gp_options', $default_options );
		add_option( 'gp_theme_version', GP_THEME_VERSION );

	}

}


/**
 * Register widgetized area
 * Register Custom Widgets
 *
 */
function gp_widgets_init() {

	// Register widgetized area
	register_sidebar( array(
		'name' => __( 'Footer Widgets', 'lang_geoprojects' ),
		'id' => 'footer-widgets',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '<h1 class="widget-title">',
		'after_title' => '</h1>',
	) );

	// Register custom widgets
	register_widget( 'gp_widget_posts_in_category' );

}

add_action( 'widgets_init', 'gp_widgets_init' );
wp_cache_delete ( 'alloptions', 'gp_options' );

/**
 * Plugin Name: Disable Embeds
 * Description: Don't like the enhanced embeds in WordPress 4.4? Easily disable the feature using this plugin.
 * Version:     1.3.0
 * Author:      Pascal Birchler
 * Author URI:  https://pascalbirchler.com
 * License:     GPLv2+
 *
 * @package disable-embeds
 */

/**
 * Disable embeds on init.
 *
 * - Removes the needed query vars.
 * - Disables oEmbed discovery.
 * - Completely removes the related JavaScript.
 *
 * @since 1.0.0
 */
function disable_embeds_init() {
	/* @var WP $wp */
	global $wp;

	// Remove the embed query var.
	$wp->public_query_vars = array_diff( $wp->public_query_vars, array(
		'embed',
	) );

	// Remove the REST API endpoint.
	remove_action( 'rest_api_init', 'wp_oembed_register_route' );

	// Turn off oEmbed auto discovery.
	add_filter( 'embed_oembed_discover', '__return_false' );

	// Don't filter oEmbed results.
	remove_filter( 'oembed_dataparse', 'wp_filter_oembed_result', 10 );

	// Remove oEmbed discovery links.
	remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );

	// Remove oEmbed-specific JavaScript from the front-end and back-end.
	remove_action( 'wp_head', 'wp_oembed_add_host_js' );
	add_filter( 'tiny_mce_plugins', 'disable_embeds_tiny_mce_plugin' );

	// Remove all embeds rewrite rules.
	add_filter( 'rewrite_rules_array', 'disable_embeds_rewrites' );

	// Remove filter of the oEmbed result before any HTTP requests are made.
	remove_filter( 'pre_oembed_result', 'wp_filter_pre_oembed_result', 10 );
}

add_action( 'init', 'disable_embeds_init', 9999 );

/**
 * Removes the 'wpembed' TinyMCE plugin.
 *
 * @since 1.0.0
 *
 * @param array $plugins List of TinyMCE plugins.
 * @return array The modified list.
 */
function disable_embeds_tiny_mce_plugin( $plugins ) {
	return array_diff( $plugins, array( 'wpembed' ) );
}

/**
 * Remove all rewrite rules related to embeds.
 *
 * @since 1.2.0
 *
 * @param array $rules WordPress rewrite rules.
 * @return array Rewrite rules without embeds rules.
 */
function disable_embeds_rewrites( $rules ) {
	foreach ( $rules as $rule => $rewrite ) {
		if ( false !== strpos( $rewrite, 'embed=true' ) ) {
			unset( $rules[ $rule ] );
		}
	}

	return $rules;
}

/**
 * Remove embeds rewrite rules on plugin activation.
 *
 * @since 1.2.0
 */
function disable_embeds_remove_rewrite_rules() {
	add_filter( 'rewrite_rules_array', 'disable_embeds_rewrites' );
	flush_rewrite_rules();
}

register_activation_hook( __FILE__, 'disable_embeds_remove_rewrite_rules' );

/**
 * Flush rewrite rules on plugin deactivation.
 *
 * @since 1.2.0
 */
function disable_embeds_flush_rewrite_rules() {
	remove_filter( 'rewrite_rules_array', 'disable_embeds_rewrites' );
	flush_rewrite_rules();
}

register_deactivation_hook( __FILE__, 'disable_embeds_flush_rewrite_rules' );