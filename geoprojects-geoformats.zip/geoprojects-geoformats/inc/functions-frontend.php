<?php
/**
 * GeoProjects Frontend funtions
 *
 * @package GeoProjects
 */

 /**
 * Theme init
 */
if ( ! function_exists( 'gp_setup' ) ) :
function gp_setup() {
	load_theme_textdomain('gp');
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
	) );
	add_theme_support( 'post-formats', array ( 'aside', 'gallery', 'quote', 'image', 'video' ) );
}
endif;
add_action( 'after_setup_theme', 'gp_setup' );

if ( ! isset ( $content_width) )
    $content_width = 1000;
	
function is_post_type($type){
	if (!is_search() ) :
		global $wp_query;
		if($type == get_post_type($wp_query->post->ID)) return true;
		return false;
		
	endif;
}
/**
 * Enqueue scripts and styles
 * and remove unused
 */
function gp_enqueue_scripts() {
	global $template;

	// If we are in all page except export map page
	if ( !( ( basename( $template ) == 'single-maps.php' ) && isset( $_GET['embed'] ) && $_GET['embed'] == 1 ) ) {
		$gp_options = get_option( 'gp_options' );

		// Leaflet CSS
	    wp_enqueue_style( 'gp_leaflet_css', GP_URL_LEAFLET . '/leaflet.css', array(), GP_THEME_VERSION, 'all' );

	    // Custom Leaflet CSS
	    wp_enqueue_style( 'gp_leaflet_map_css', GP_URL_CSS . '/leaflet-map.css', array(), GP_THEME_VERSION, 'all' );

	    // MediaElement CSS
	    wp_enqueue_style( 'mediaelement' );
	    wp_enqueue_style( 'wp-mediaelement' );
		
		//FontAwesome
		wp_register_style( 'style-css', get_template_directory_uri() . '/style.css' );
		wp_enqueue_style( 'style-css');
		wp_enqueue_style( 'fontawesome', get_template_directory_uri() . '/libs/fontawesome/css/font-awesome.min.css' );
		
		// Frontend JS
		// Including : Respond.js, the small navigation menu trigger, fitvids.js, iOS orientation fix
		wp_enqueue_script( 'gp_frontend_js', GP_URL_JS . '/frontend.js', array( 'jquery' ), GP_THEME_VERSION, true );
		
		wp_localize_script( 'jquery', 'gpGlobalVars', gp_js_global_vars() );

	    // Some i18n
	    wp_localize_script( 'jquery', 'gpGlobalI18n', gp_js_i18n() );

		// JS for comment replying
		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}
	}
	//Styles Geoformat
		if( is_post_type('geoformat') && !is_archive() ) {
			wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/libs/bootstrap/bootstrap.min.css');
			wp_enqueue_style( 'stylegeoformat', get_template_directory_uri() . '/css/geoformat/geoformat.css');
			wp_enqueue_style( 'normalize', get_template_directory_uri() . '/css/geoformat/normalize.css');
			wp_register_script('bootstrapmin', get_template_directory_uri() . '/libs/bootstrap/bootstrap.min.js','','1.0',true);
			wp_enqueue_script( 'bootstrapmin' );
			wp_register_script('classie', get_template_directory_uri() . '/js/geoformat/classie.js','','1.0',true);
			wp_enqueue_script( 'classie' );
			wp_register_script('loader', get_template_directory_uri() . '/js/geoformat/jquery.classyloader.min.js','','1.0',true);
			wp_enqueue_script( 'loader' );
			wp_register_script('geoformatjs', get_template_directory_uri() . '/js/geoformat/geoformat.js','','1.0',true);
			wp_enqueue_script( 'geoformatjs' );
		}
		
		
	// Leaflet JS
	
    wp_enqueue_script( 'gp_leaflet_js', GP_URL_LEAFLET . '/leaflet.js', array( 'jquery' ), GP_THEME_VERSION, false );

    // Custom Leaflet JS
  
    wp_enqueue_script( 'gp_leaflet_wrapper_js', GP_URL_JS . '/leaflet-wrapper.js', array( 'jquery', 'gp_leaflet_js' ), GP_THEME_VERSION, false );

    // Custom JS (reloaded here for placing it after leaflet)
   
    wp_enqueue_script( 'gp_frontend_js', GP_URL_JS . '/frontend.js', array( 'jquery', 'gp_leaflet_wrapper_js' ), GP_THEME_VERSION, false );


}

add_action( 'wp_enqueue_scripts', 'gp_enqueue_scripts' );

//Parsing du JS différé
if (!(is_admin() )) {
    function defer_parsing_of_js ( $url ) {
        if ( FALSE === strpos( $url, '.js' ) ) return $url;
        if ( strpos( $url, 'jquery.js' ) ) return $url;
        return "$url' defer onload='";
    }
    add_filter( 'clean_url', 'defer_parsing_of_js', 11, 1 );
}

//Suppress Emoji
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'admin_print_styles', 'print_emoji_styles' ); 

//Suppress infos WP 
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'wp_shortlink_wp_head', 10, 0 );
remove_action('wp_head', 'wp_dlmp_l10n_style' );
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wlwmanifest_link');

function gp_remove_version() {
	return '<!--GEOPROJECT-->';
}
add_filter('the_generator', 'gp_remove_version');
	
//Suppression IPTAGS
	function gp_remove_img_ptags($content){
		return preg_replace('/<p>\s*(<a .*>)?\s*(<img .* \/>)\s*(\/a>)?\s*<\/p>/iU', '\1\2\3', $content);
	}
	add_filter('the_content', 'gp_remove_img_ptags');

if ( ! function_exists( '_wp_render_title_tag' ) ) {
	function gp_theme_slug_render_title() {
	?>
		<title><?php wp_title( '|', true, 'right' ); ?></title>
	<?php
	}
	add_action( 'wp_head', 'gp_theme_slug_render_title' );
}

add_theme_support( 'title-tag' );

//Si IE 9

function gp_IEhtml5_shim () {
	global $is_IE;
	if ($is_IE)
	echo '<!--[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->';
}
add_action('wp_head', 'gp_IEhtml5_shim');


/**
 * Customize title and url of login page
 */
function gp_login_headerurl() {
	return get_bloginfo( 'url' );
}

function gp_login_headertitle() {
	return get_option( 'blogname' );
}

add_filter( 'login_headerurl', 'gp_login_headerurl' );
add_filter( 'login_headertitle', 'gp_login_headertitle' );


/**
 * Get a custom Excerpt regarding the given type
 * @param  string $type Type of the excerpt.
 */
function gp_get_custom_excerpt( $type = 'default', $with_more_link = true ) {
	global $post;
	$excerpt_more_link = ( $with_more_link ) ? ' <a href="' . get_permalink( $post ) . '" class="entry-more">' . __( 'more', 'lm3' ) . '...</a>' : '...';

	switch( $type ) {
		case 'post-in-project-list':
			$excerpt_length = GP_DEFAULT_EXCERPT_POST_IN_PROJECT_LIST;
			break;
		case 'side-map':
			$excerpt_length = GP_DEFAULT_EXCERPT_SIDE_POST;
			break;
		default:
			$excerpt_length = GP_DEFAULT_EXCERPT_LENGTH;
			break;
	}

	// Has already a manual excerpt
	if ( has_excerpt() ) {
		$output_excerpt = $post->post_excerpt . $excerpt_more_link;
	}
	// Generate an excerpt
	else {
		$output_excerpt = get_the_content( '' );
		$output_excerpt = strip_shortcodes( $output_excerpt );
		$output_excerpt = apply_filters( 'the_content', $output_excerpt );
		$output_excerpt = str_replace( ']]>', ']]&gt;', $output_excerpt );
		$output_excerpt = wp_trim_words( $output_excerpt, $excerpt_length, $excerpt_more_link );
	}

	echo $output_excerpt;
}


/**
 * Add necessary Leaflet JS for displaying a map
 */
function gp_load_frontend_leaflet() {

}


/**
Metadata : Open Graph, Twitter Card, Dublin Core
**/

function gp_share_social() {
	if ( !is_404() && !is_search() ) {
		
		global $post;
		$cpt = $post->post_type;
		$description = my_excerpt( $post->post_content, $post->post_excerpt );
		$description = strip_tags($description);
		$description = str_replace("\"", "'", $description);
		$cat = get_the_category(); 
		
		$fname = get_the_author_meta('first_name');
		$lname = get_the_author_meta('last_name');
		$author = trim( "$fname $lname" );
		$site_lang = get_bloginfo('language');
		
		if(get_the_post_thumbnail($post->ID, 'thumbnail')) {
			$thumbnail_id = get_post_thumbnail_id($post->ID);
			$thumbnail_object = get_post($thumbnail_id);
			$image = $thumbnail_object->guid;
		} else {	
			$image = ''; 
		}
		
/*If Not a Single Page*/
	if ( !is_single() || is_home() ) { ?> 
<meta name="DC.Title" content="<?php the_title(); ?>">
<meta name="DC.Publisher" content="<?php echo get_bloginfo('name'); ?>">
<meta name="DC.Language" scheme="UTF-8" content="<?php echo $site_lang; ?>">
<meta property="og:title" content="<?php the_title(); ?>" />
	<?php }
/*If is a Single Page*/
	if (is_single() || $cpt == 'geoformat' ) {	?>
<meta property="og:title" content="<?php the_title(); ?>" />
<?php if (!empty($description)) { ?>
<meta property="og:description" content="<?php echo $description ?>" />
<?php } ?>
<meta property="og:type" content="article" />
<meta property="og:url" content="<?php the_permalink(); ?>" />
<meta property="og:image" content="<?php echo $image; ?>">
<meta property="og:site_name" content="<?php echo get_bloginfo('name'); ?>" />
<meta name="twitter:card" value="summary_large_image" />
<meta name="twitter:url" value="<?php the_permalink(); ?>" />
<meta name="twitter:title" value="<?php the_title(); ?>" />
<?php if (!empty($description)) { ?>
<meta name="twitter:description" value="<?php echo $description; ?>" />
<?php } ?>
<meta name="twitter:image" value="<?php echo $image; ?>" />
<?php $gp_options = get_option( 'gp_options' ); $twitter_id = $gp_options['twitter_id'];
	if (!empty($twitter_id) ){ ?>
<meta name="twitter:site" value="<?php echo $twitter_id; ?>" />
<meta name="twitter:creator" value="<?php echo $twitter_id; ?>" />
<?php } if ( $author ) { ?>
<meta name="DC.Creator" content="<?php echo $author; ?>">
<?php }  
if (has_category()) { ?>
<meta name="DC.Subject" content="<?php echo $cat; ?>">
<?php } 
if (!empty($description)) { ?>
<meta name="DC.Description" content="<?php echo $description; ?>">
<?php } ?>
<meta name="DC.Identifier" content="<?php the_permalink(); ?>">
<meta name="DC.Date" content="<?php the_time('Y-m-d'); ?>">
<meta name="DC.Title" content="<?php the_title(); ?>">
<meta name="DC.Publisher" content="<?php echo get_bloginfo('name'); ?>">
<meta name="DC.Language" scheme="UTF-8" content="<?php echo $site_lang; ?>">
<?php } 
	
/*close 404*/	
	}
}

function my_excerpt($text, $excerpt){
	
    if ($excerpt) return $excerpt;

    $text = strip_shortcodes( $text );
    $text = apply_filters('the_content', $text);
    $text = str_replace(']]>', ']]&gt;', $text);
    $text = strip_tags($text);
    $excerpt_length = apply_filters('excerpt_length', 55);
    $excerpt_more = apply_filters('excerpt_more', ' ' . '[...]');
    $words = preg_split("/[\n
	 ]+/", $text, $excerpt_length + 1, PREG_SPLIT_NO_EMPTY);
    if ( count($words) > $excerpt_length ) {
            array_pop($words);
            $text = implode(' ', $words);
            $text = $text . $excerpt_more;
    } else {
            $text = implode(' ', $words);
    }

    return apply_filters('wp_trim_excerpt', $text, $excerpt);
}
add_action( 'wp_head', 'gp_share_social' );