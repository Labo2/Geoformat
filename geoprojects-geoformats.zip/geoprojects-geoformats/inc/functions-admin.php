<?php
/**
 * GeoProjects Admin funtions
 *
 * @package GeoProjects
 */


/**
 * Require Admin utils functions
 */
require_once( GP_PATH_INC . '/functions-admin-utils.php' );


/**
 * Register Metaboxes
 */
require_once( GP_PATH_MBOX . '/projects-list.php' );
require_once( GP_PATH_MBOX . '/project-infos.php' );
require_once( GP_PATH_MBOX . '/map-preview.php' );
require_once( GP_PATH_MBOX . '/map-infos.php' );
require_once( GP_PATH_MBOX . '/marker-infos.php' );


/**
 * Add custom colums and filters in listings
 */
require_once( GP_PATH_OTHERS . '/custom-listing-columns.php' );
require_once( GP_PATH_OTHERS . '/custom-listing-filters.php' );


/**
 * Add Theme Settings page
 */
require_once( GP_PATH_OTHERS . '/admin-menus.php' );

/**
 * Guidelines on dashboard
 */
require_once( GP_PATH_OTHERS . '/dashboard.php' );


/**
 * Admin Init
 * - Register settings fields
 */
function gp_admin_init() {
    // Register settings
    if ( current_user_can( 'delete_others_posts' ) ) {
        require( GP_PATH_OTHERS . '/settings.php' );
		gp_register_settings();
    }   
}
add_action( 'admin_init', 'gp_admin_init' );

/**
 * Enqueue CSS and JS for Admin
 */
function gp_admin_enqueue_scripts( $hook ) {
    global $post_type, $pagenow;
    $gp_options = get_option( 'gp_options' );

	// Admin CSS
	wp_enqueue_style( 'gp_admin_css', GP_URL_CSS . '/admin.css', array(), GP_THEME_VERSION, 'all' );

    // For Map / Marker Forms and settings page
    if ( $post_type == 'geoformat' || $post_type == 'markers' || $post_type == 'maps' || ( $pagenow == 'admin.php' && isset( $_GET['page'] ) && $_GET['page'] == 'gp_geoprojects_page' ) ) {
		
        // Leaflet CSS
        wp_enqueue_style( 'gp_leaflet_css', GP_URL_LEAFLET . '/leaflet.css', array(), GP_THEME_VERSION, 'all' );

        // Custom Leaflet CSS
        wp_enqueue_style( 'gp_leaflet_map_css', GP_URL_CSS . '/leaflet-map.css', array(), GP_THEME_VERSION, 'all' );

        // Leaflet JS
        wp_enqueue_script( 'gp_leaflet_js', GP_URL_LEAFLET . '/leaflet.js', array( 'jquery' ), GP_THEME_VERSION, true );

        // Custom Leaflet JS
        wp_enqueue_script( 'gp_leaflet_wrapper_js', GP_URL_JS . '/leaflet-wrapper.js', array( 'jquery', 'gp_leaflet_js' ), GP_THEME_VERSION, true );

    }

    // For Settings page
    if ( $pagenow == 'admin.php' && isset( $_GET['page'] ) && $_GET['page'] == 'gp_geoprojects_page' ) {
        wp_enqueue_script( 'wp-color-picker' );
        wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script('media-upload');
		wp_enqueue_script('thickbox');
		wp_enqueue_style('thickbox');
    }

    // MediaElement CSS for Map / Marker Forms
    if ( $post_type == 'markers' || $post_type == 'maps' || $post_type == 'geoformat'  ) {

        // MediaElement CSS
        wp_enqueue_style( 'mediaelement' );
        wp_enqueue_style( 'wp-mediaelement' );

    }

    // Admin JS
    wp_enqueue_script( 'gp_admin_js', GP_URL_JS . '/admin.js', array( 'jquery' ), GP_THEME_VERSION, true );
  
    // Some global vars
    wp_localize_script( 'jquery', 'gpGlobalVars', gp_js_global_vars() );

    // Some i18n
    wp_localize_script( 'jquery', 'gpGlobalI18n', gp_js_i18n() );

}

add_action( 'admin_enqueue_scripts', 'gp_admin_enqueue_scripts' );


/*
 * Customise the WYSIWYG buttons
 */
function gp_custom_wysiwyg_buttons( $init ) {
  	// block formats available
  	$init['theme_advanced_blockformats'] = 'p,h2,h3,h4,h5';
  	// some buttons suppressed
  	$init['theme_advanced_disable'] = 'blockquote,pastetext,pasteword,justifyfull';
  	return $init;
}

add_filter( 'tiny_mce_before_init', 'gp_custom_wysiwyg_buttons' );


/**
 * Add custom posts types counts to Dashboard widget
 */

function gp_add_cpt_counts_to_dashboard_glance_items() {

  $post_types = get_post_types( array( '_builtin' => false ), 'objects' );

  foreach ( $post_types as $post_type ) {

    if($post_type->show_in_menu==false) {
      continue;
    }

    $num_posts = wp_count_posts( $post_type->name );
    $num = number_format_i18n( $num_posts->publish );
    $text = _n( $post_type->labels->singular_name, $post_type->labels->name, $num_posts->publish );
    if ( current_user_can( 'edit_posts' ) ) {
        $output = '<a href="edit.php?post_type=' . $post_type->name . '">' . $num . ' ' . $text . '</a>';
    }
    echo '<li class="page-count-geo ' . $post_type->name . '-count">' . $output . '</td>';
  }
}
add_filter( 'dashboard_glance_items', 'gp_add_cpt_counts_to_dashboard_glance_items' );


/**
 * Hide Wordpress Update notice for all but admin
 */
function gp_hide_update_notice_to_all_but_admin_users() 
{
    if ( !current_user_can( 'update_core' ) ) {
        remove_action( 'admin_notices', 'update_nag', 3 );
    }
}

add_action( 'admin_notices', 'gp_hide_update_notice_to_all_but_admin_users', 1 );


/**
 * Modify the admin footer text
 */
function gp_admin_footer_text () {
    bloginfo( 'description' );
}

add_filter( 'admin_footer_text', 'gp_admin_footer_text' );

/*CPT ARchives menu**/
add_action('admin_head-nav-menus.php', 'wpclean_add_metabox_menu_posttype_archive');

function wpclean_add_metabox_menu_posttype_archive() {
add_meta_box('wpclean-metabox-nav-menu-posttype', 'Archives', 'wpclean_metabox_menu_posttype_archive', 'nav-menus', 'side', 'default');
}

function wpclean_metabox_menu_posttype_archive() {
$post_types = get_post_types(array('show_in_nav_menus' => true, 'has_archive' => true), 'object');

if ($post_types) :
    $items = array();
    $loop_index = 999999;

    foreach ($post_types as $post_type) {
        $item = new stdClass();
        $loop_index++;

        $item->object_id = $loop_index;
        $item->db_id = 0;
        $item->object = 'post_type_' . $post_type->query_var;
        $item->menu_item_parent = 0;
        $item->type = 'custom';
        $item->title = $post_type->labels->name;
        $item->url = get_post_type_archive_link($post_type->query_var);
        $item->target = '';
        $item->attr_title = '';
        $item->classes = array();
        $item->xfn = '';

        $items[] = $item;
    }

    $walker = new Walker_Nav_Menu_Checklist(array());

    echo '<div id="posttype-archive" class="posttypediv">';
    echo '<div id="tabs-panel-posttype-archive" class="tabs-panel tabs-panel-active">';
    echo '<ul id="posttype-archive-checklist" class="categorychecklist form-no-clear">';
    echo walk_nav_menu_tree(array_map('wp_setup_nav_menu_item', $items), 0, (object) array('walker' => $walker));
    echo '</ul>';
    echo '</div>';
    echo '</div>';

    echo '<p class="button-controls">';
    echo '<span class="add-to-menu">';
    echo '<input type="submit"' . disabled(1, 0) . ' class="button-secondary submit-add-to-menu right" value="' . __('Add to Menu', 'andromedamedia') . '" name="add-posttype-archive-menu-item" id="submit-posttype-archive" />';
    echo '<span class="spinner"></span>';
    echo '</span>';
    echo '</p>';

endif;
}
/**CALLING THE MEA IMAGE BOX FOR GEOFORMAT**/

add_action( 'admin_enqueue_scripts', 'geoformat_image_enqueue' );
function geoformat_image_enqueue() {
	global $typenow;
	$plugin_dir_uri = plugin_dir_url( __FILE__ );
    if( $typenow == 'geoformat' && is_admin() ) {
        wp_enqueue_media();
        wp_register_script( 'meta-box-image',  GP_URL_JS . '/geoformat/geoformat-img-box.js', array( 'jquery' ) );
        wp_localize_script( 'meta-box-image', 'meta_image',
            array(
                'title' => __( 'Choose your image', 'lang_geoprojects' ),
                'button' => __( 'Use this image', 'lang_geoprojects' ),
            )
        );
        wp_enqueue_script( 'meta-box-image' );
    }
}