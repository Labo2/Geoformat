<?php if( !empty( $meta_font)) {
		if ($meta_font == "select-seven") { ?>	<link href='https://fonts.googleapis.com/css?family=Droid+Sans:400,700' rel='stylesheet' type='text/css'> 	
		<?php } else if ($meta_font == "select-eight") { ?> <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font == "select-six") { ?> <link href='https://fonts.googleapis.com/css?family=Arvo:400,700' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font == "select-nine") { ?> <link href='https://fonts.googleapis.com/css?family=Roboto:400,700' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font == "select-ten") { ?> <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,700' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font == "select-eleven") { ?> <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'> 
		<?php } else if ($meta_font == "select-twelve") { ?> <link href='https://fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font == "select-thirteen") { ?> <link href='https://fonts.googleapis.com/css?family=Inconsolata' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font == "select-fourteen") { ?> <link href='https://fonts.googleapis.com/css?family=Playfair+Display' rel='stylesheet' type='text/css'> 
		<?php } 
		if ( !empty( $meta_font_title) ) {?>	
		<?php if ($meta_font_title == "select-one") { ?> 	<link href='https://fonts.googleapis.com/css?family=Droid+Sans:400,700' rel='stylesheet' type='text/css'> 	
		<?php } else if ($meta_font_title == "select-two") { ?> <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font_title  == "select-three") { ?> <link href='https://fonts.googleapis.com/css?family=Arvo:400,700' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font_title == "select-four") { ?> 	<link href='https://fonts.googleapis.com/css?family=Roboto:400,700' rel='stylesheet' type='text/css'> 
		<?php } else if ($meta_font_title == "select-five") { ?> <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,700' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font_title == "select-six") { ?> <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'> 
		<?php } else if ($meta_font_title == "select-seven" || $meta_font == "select-twelve") { ?> <link href='https://fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font_title == "select-eight") { ?> <link href='https://fonts.googleapis.com/css?family=Inconsolata' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font_title == "select-nine") { ?> <link href='https://fonts.googleapis.com/css?family=Playfair+Display' rel='stylesheet' type='text/css'>	
		<?php } else if ($meta_font_title == "select-ten") { ?> <link href='https://fonts.googleapis.com/css?family=Raleway:600' rel='stylesheet' type='text/css'> 
		<?php } 	
	    } 
	} ?>
	
<style type="text/css">

    /* Background and font */
	
	<?php 
	if ($meta_font == "select-one") { ?>	
	html, body {font-family: Arial, Helvetica, sans-serif!important;}	
	<?php } else if ($meta_font == "select-two") { ?>	
	html, body {font-family: Georgia, serif!important;font-size:1.1em;}	
	.section_title {font-size: 4em;}	
	<?php } else if ($meta_font == "select-three") { ?> 
	html, body {font-family: Tahoma, Geneva, sans-serif!important;}	
	<?php } else if ($meta_font == "select-four") { ?>	
	html, body {font-family: "Times New Roman", Times, serif!important;font-size:1.1em;}	
	.section_title {font-size: 4em;}	
	<?php } else if ($meta_font == "select-five") { ?>	
	html, body {font-family: Verdana, Geneva, sans-serif!important;}	
	<?php } else if ($meta_font == "select-six") { ?>	
	html, body {font-family: 'Arvo', serif!important;}	
	<?php } else if ($meta_font == "select-seven") { ?>	
	html, body {font-family: 'Droid Sans', sans-serif!important;}	
	<?php } else if ($meta_font == "select-eight") { ?>	
	html, body {font-family: 'Open Sans', sans-serif!important;}	<?php } 
	else if ($meta_font == "select-nine") { ?>	
	html, body {font-family: 'Roboto', sans-serif!important;}	
	<?php } else if ($meta_font == "select-ten") { ?>	
	html, body {font-family:'Roboto Slab', serif!important;font-size:1.1em;}	
	<?php } else if ($meta_font == "select-eleven") { ?>	
	html, body {font-family: 'Lato', sans-serif!important;}	
	<?php } else if ($meta_font == "select-twelve") { ?>	
	html, body {font-family: 'Ubuntu Condensed', sans-serif!important;font-size:1.3em;}	
	<?php } else if ($meta_font == "select-thirteen") { ?>	
	html, body {font-family: 'Inconsolata', cursive!important;}	
	<?php } else if ($meta_font == "select-fourteen") { ?>	
	html, body {font-family: 'Playfair Display', serif!important;}	
	<?php }	
	
	
	/*Titles*/
	if( !empty( $meta_font_title ) ) { 
		if ($meta_font_title == "select-one") { ?>	
		h1,h2,h3,h4,h5 {font-family: 'Droid Sans', sans-serif!important;}	  
		<?php } else if ($meta_font_title == "select-two") { ?>	
		h1,h2,h3,h4,h5 {font-family: 'Open Sans', sans-serif!important;}	   	
		<?php } else if ($meta_font_title  == "select-three") { ?>	
		h1,h2,h3,h4,h5 {font-family: 'Arvo', serif!important;}
		<?php } else if ($meta_font_title == "select-four") { ?>	
		h1,h2,h3,h4,h5 {font-family: 'Roboto', sans-serif!important;}	 
		<?php } else if ($meta_font_title == "select-five") { ?>	
		h1,h2,h3,h4,h5 {font-family: 'Roboto Slab', serif!important;}	
		<?php } else if ($meta_font_title == "select-six") { ?>	
		h1,h2,h3,h4,h5 {font-family: 'Lato', sans-serif!important;}	
		<?php } else if ($meta_font_title == "select-seven") { ?>	
		h1,h2,h3,h4,h5 {font-family: 'Ubuntu Condensed', sans-serif!important;}
		<?php } else if ($meta_font_title == "select-eight") { ?>	
		h1,h2,h3,h4,h5 {font-family: 'Inconsolata', cursive!important;}	
		<?php } else if ($meta_font_title == "select-nine") { ?>	
		h1,h2,h3,h4,h5 {font-family: 'Playfair Display', serif!important;}	
		<?php } else if ($meta_font_title == "select-ten") { ?>	
		h1,h2,h3,h4,h5 {font-family: 'Raleway', sans-serif!important;}	
		<?php } 
	}	
	?>
	
	
	/* Title Color */

    .site-title a:link,
    .site-title a:visited {color:<?php echo $title_color; ?>;}
    .site-title a:hover,
    .site-title a:active,
    .site-title a:focus {color:<?php echo $secondary_color; ?>;}
	.submit:hover {background:<?php echo $secondary_color; ?>;color:#FFFFFF;}
    /* Tagline Color */

    .site-description {color:<?php echo $tagline_color; ?>;}
    
    /* Primary Color */

    a:link,
    a:visited,
    .gp-leaflet-map-container .gp-map-markers-index ul a:link,
    .gp-leaflet-map-container .gp-map-markers-index ul a:visited    {color:<?php echo $primary_color; ?>}

    #projects-list li a:link,
    #projects-list li a:visited,
    .entry-summary .entry-more:link,
    .entry-summary .entry-more:visited,
    .site-navigation a:link, 
    .site-navigation a:visited,
    .widget-posts-in-list-more a:link,
    .widget-posts-in-list-more a:visited {background-color:<?php echo $primary_color; ?>;}

    #site-navigation ul li {border-bottom-color:<?php echo $primary_color; ?>;}
	
    /* Secondary Color */

    a:hover,
    a:active,
    a:focus {color:<?php echo $secondary_color; ?>;}
	
	.latest-maps h4,.gp-map-export,.gp-map-export-map-toggle:link, .gp-map-export-map-toggle:visited,
	.abstract, .gp-map-actions-toggles .gp-map-markers-index-toggle:link, 
	.gp-map-actions-toggles .gp-map-markers-index-toggle:visited,.homesideprojects li
	{background-color:<?php echo $primary_color; ?>!important;color:#FFFFFF!important;}
	
	.gp-map-markers-index-toggle:hover, .gp-map-markers-index-toggle:active, 
	.gp-map-markers-index-toggle:focus, .gp-map-markers-index-toggle.active,
	.gp-map-export-map-toggle:hover, .gp-map-export-map-toggle:active, 
	.gp-map-export-map-toggle:focus, 
	.gp-map-export-map-toggle.active, .leaflet-popup-content .map-popup-marker-more a:link, .leaflet-popup-content .map-popup-marker-more a:visited	{
    background-color: <?php echo $secondary_color; ?>!important;color:#FFFFFF!important;}
	
	.gp-leaflet-map-container .gp-map-markers-index ul  {border-bottom:1px solid <?php echo $secondary_color; ?>}


    #site-navigation ul a:hover,
    #site-navigation ul a:active,
    #site-navigation ul a:focus,
    #site-navigation ul .current-menu-item a,
    #site-navigation ul .current_page_item a,
    #projects-list li a:hover,
    #projects-list li a:active,
    #projects-list li a:focus,
    #projects-list li.current-project-page a,
    .entry-summary .entry-more:active,
    .entry-summary .entry-more:focus,
    article.type-projects,
    .gp-leaflet-map-container .gp-map-markers-index ul,
    .site-navigation a:hover,
    .site-navigation a:active,
    .site-navigation a:focus,
    .widget-posts-in-list-more a:hover,
    .widget-posts-in-list-more a:active,
    .widget-posts-in-list-more a:focus {background-color:<?php echo $secondary_color; ?>;color:#FFFFFF!important;}
	.entry-summary .entry-more:hover{background-color:<?php echo $primary_color; ?>;}
	#site-navigation ul li{border-top:4px solid <?php echo $secondary_color; ?>!important;background-color:<?php echo $primary_color; ?>;}
	#site-navigation ul li:hover {border-top:4px solid<?php echo $primary_color; ?>!important;background-color:<?php echo $primary_color; ?>;}
	#projects-list li.current-project-page a {background-color:<?php echo $primary_color; ?>!important;}
	#projects-list li.current-project-page a:hover {background-color:<?php echo $secondary_color; ?>!important;}
	.title-home{background-color:<?php echo $primary_color; ?>!important;padding:10px;color:#FFFFFF;}
    /* ---------------------
      550px <= Width
    --------------------- */

    @media screen and (min-width: 550px) {

        /* Primary Color */

        #site-navigation ul a                                       {border-top-color:<?php echo $primary_color; ?>}

        .gp-map-actions-toggles .gp-map-markers-index-toggle:hover,
        .gp-map-actions-toggles .gp-map-markers-index-toggle:active,
        .gp-map-actions-toggles .gp-map-markers-index-toggle:focus,
        .gp-map-actions-toggles .gp-map-markers-index-toggle.active,
        .gp-map-actions-toggles .gp-map-export-map-toggle:hover,
        .gp-map-actions-toggles .gp-map-export-map-toggle:active,
        .gp-map-actions-toggles .gp-map-export-map-toggle:focus,
        .gp-map-actions-toggles .gp-map-export-map-toggle.active    {background-color:<?php echo $primary_color; ?>}

        /* Secondary Color */

        #site-navigation ul .current-menu-item a,
        .gp-map-actions-toggles .gp-map-markers-index-toggle:link,
        .gp-map-actions-toggles .gp-map-markers-index-toggle:visited,
        .gp-map-actions-toggles .gp-map-export-map-toggle:link,
        .gp-map-actions-toggles .gp-map-export-map-toggle:visited   {background-color:<?php echo $secondary_color; ?>}

        .gp-map-actions-toggles a                                   {border-color:<?php echo $secondary_color; ?>}

    }

</style>