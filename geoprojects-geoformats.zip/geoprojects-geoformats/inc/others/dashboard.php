<?php function geoproject_dashboard_widget_function() {
?>
	<div id="lab" style="font-size:1.1em!important;">
		<ul style="list-style-type:square;padding-left:12px;">
			<li><?php _e('No field is required: an unfilled field will not be displayed.','lang_geoprojects'); ?></li>
			<li><?php _e('One exception is the "subtitle" field, this text is used for description metadata as well as for sharing on social networks.','lang_geoprojects'); ?></li>
			<li><?php _e('Image formats at the top of section: 1400px wide x 777px high. The display of the image in full page will depend on the size of the screen.','lang_geoprojects'); ?></li>
			<li><?php _e('As a simple article, Geoformat accepts labels, categories, and  featured image (this is used to display Geoformats on the home page and in category pages)..','lang_geoprojects'); ?></li>
			<li><?php _e('As a classic article, editing allows WYSIWYG formatting as well as the insertion of multimedia elements.','lang_geoprojects'); ?></li>
		</ul>
		
		<h3 style="font-size:22px;margin:25px 0;"><?php _e('Sidebar Settings','lang_geoprojects'); ?></h3>
		
		<h4 style="font-size:20px;color:#696969;"><?php _e('General:','lang_geoprojects'); ?></h4>
			<ul style="list-style-type:square;padding-left:12px;">
				<li><?php _e('Text size','lang_geoprojects'); ?></li>
				<li><?php _e('Width of the central column','lang_geoprojects'); ?></li>
				<li><?php _e('Border style for blockquotes','lang_geoprojects'); ?></li>
			</ul>
		<h4 style="font-size:20px;color:#696969;"><?php _e('Intro:','lang_geoprojects'); ?></h4>
			<ul style="list-style-type:square;padding-left:12px;">
				<li><?php _e('Display the author\'s name in the loading intro','lang_geoprojects'); ?></li>
				<li><?php _e('Choice of the loader for loading (circle, by default)','lang_geoprojects'); ?></li>
				<li><?php _e('Animation of the loader to its disappearance','lang_geoprojects'); ?></li>
				<li><?php _e('Geoformat intro effect','lang_geoprojects'); ?></li>
				<li><?php _e('Style of the  "trigger" button (permits to pass from the full screen introduction to the contents)','lang_geoprojects'); ?></li>
			</ul>
		<h4 style="font-size:20px;color:#696969;"><?php _e('Navigation:','lang_geoprojects'); ?></h4>
			<ul style="list-style-type:square;padding-left:12px;">
				<li><?php _e('Position of the progress bar or deactivation of this function','lang_geoprojects'); ?></li>
				<li><?php _e('Position and style of the fixed navigation bar (header or footer, background color, Geoformat title or not, intrapage navigation methode - via the hamburger drop-down menu - and appearance of social network icons)','lang_geoprojects'); ?></li>
			</ul>
	</div>
<?php
}
function example_add_geoproject_dashboard_widgets() {
	wp_add_dashboard_widget('geoproject_dashboard_widget', __( 'Geoformat: guidelines', 'lang_geoprojects' ), 'geoproject_dashboard_widget_function');
}
add_action('wp_dashboard_setup', 'example_add_geoproject_dashboard_widgets' );
?>