<?php
/**
 * Template : Help - Credits
 */
?>

<div id="page_help" class="wrap">
  
	<div id="icon-options-general" class="icon32"><br></div>
	<h2><?php _e( 'Help and Credits', 'lang_geoprojects' ); ?></h2>

	<h3>
		<?php _e( 'Organization of Contents', 'lang_geoprojects' ); ?>
	</h3>

	<p>
		<?php _e( 'The GeoProjects Wordpress theme adds 4 content types : Projects, Maps, Markers and Geoformats.', 'lang_geoprojects' ); ?>
	</p>
	<p>
		<?php _e( 'A Map contain markers and can be associated to a Project. You can also associate Geoformats as well as the traditionnals WordPress posts to Projects.', 'lang_geoprojects' ); ?>
	</p>
	<p>
		<?php _e( 'Markers can contain text, images, sound or video (and a mix of them), and you can provide you own icons to show up on the maps.', 'lang_geoprojects' ); ?>
	</p>

	<h3>
		<?php _e( 'Geoformat', 'lang_geoprojects' ); ?>
	</h3>

	<p>
		<?php _e( 'The post type Geoformat permits you to create longform contents. Each new section is introduced with a title and a background map or a background image or a background video. The edit zones are well specified. A field not filled won\'t be displayed. The "subline" filed is used to display an abstract of the document on the front-pages and is also used for metadata (OpenGraph, Twitter Card and Dublin Core).', 'lang_geoprojects' ); ?>
	</p>
	
	<p><?php _e('You can create photo galleries or use third parties plugins to add graphical dynamic contents. The "Formats" button, available above each edit zone, permits you to create frames, dropcaps and buttons. ', 'lang_geoprojects' ); ?>
	
		<?php _e( 'The official documentation of the original plugin can be found', 'lang_geoprojects' ); ?>
		<a href="http://www.ohmybox.info/?s=simple+long+form&submit=ok" target="_blank">
		<?php _e( 'on the website of the plugin\'s author.', 'lang_geoprojects' ); ?>
		</a>
	</p>

	<h3>
		<?php _e( 'Big Map Page', 'lang_geoprojects' ); ?>
	</h3>

	<p>
		<?php _e( 'The GeoProjects theme comes with a special page showing all Markers of all Maps.', 'lang_geoprojects' ); ?>
	</p>

	<p>
		<?php _e( 'To use it, create a new Page, and set its "Model" to "Big Map". You can then add this page to your menu.', 'lang_geoprojects' ); ?>
	</p>

	<h3>
		<?php _e( 'Widgets', 'lang_geoprojects' ); ?>
	</h3>

	<p>
		<?php _e( 'This theme has a Widgets zone in the footer, where you can add any of them. There is a specific widget for Geoformats, if you wish to display the  list of the last longform publications.', 'lang_geoprojects' ); ?>
	</p>

	<h2>
		<?php _e( 'Credits - License', 'lang_geoprojects' ); ?>
	</h2>

	<p>
		<?php
		printf(
		 	__( 'This Wordpress theme has been developped by %1$s and funded by the %2$s. The 2.0 version, which includes the Geoformat post type, is developed by Laurence Dierickx (%3$s), from the original plugin Simple Long Form, developed as an open source software for WordPress.', 'lang_geoprojects' ),
		 	'<a href="http://labomedia.org" target="_blank">Labomedia</a>',
		 	'<a href="http://bibliotheque.nimes.fr" target="_blank">Carré d\'Art Bibliothèques de Nîmes</a>',
			'<a href="http://www.ohmybox.info" target="_blank">OhMyBox.info</a>'
		);
		?>
	</p>

	<p>
		<?php
		printf(
			__( 'Released under the GPL v.2 license, you can download this theme on %1$s. Please, feel free to report bugs and submit fixes or new features !', 'lang_geoprojects' ),
			'<a href="https://github.com/Labomedia/lm-maps-manager">GitHub</a>'
		); ?>
	</p>

</div>