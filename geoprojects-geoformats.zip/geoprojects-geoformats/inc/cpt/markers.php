<?php

/**
 * CUSTOM POST TYPE : Markers
 */

 
/**
 * Class definition of the CPT "Markers"
 */
class gp_cpt_markers {

	var $type   = 'markers';


	/**
	 * Constructor
	 */
	function __construct() {
		$this->single = __( 'Marker', 'lang_geoprojects' );
		$this->plural = __( 'Markers', 'lang_geoprojects' );
	}


	/**
	* Define and register the post type
	*/  
	function add_post_type(){

		$labels = array(
			'name'                	=> __( 'Markers', 'lang_geoprojects' ),
			'singular_name'       	=> __( 'Marker', 'lang_geoprojects' ),
			'add_new'             	=> __( 'Add', 'lang_geoprojects' ),
			'add_new_item'        	=> __( 'Add a new marker', 'lang_geoprojects' ),
			'edit_item'           	=> __( 'Edit this marker', 'lang_geoprojects' ),
			'new_item'            	=> __( 'New marker', 'lang_geoprojects' ),
			'view_item'           	=> __( 'See the marker', 'lang_geoprojects' ),
			'search_items'        	=> __( 'Search markers', 'lang_geoprojects' ),
			'not_found'           	=> __( 'No markers found', 'lang_geoprojects' ),
			'not_found_in_trash'  	=> __( 'No markers found in trash', 'lang_geoprojects' ),
			'parent_item_colon'   	=> __( 'My markers', 'lang_geoprojects' )
		);

		$options = array(
			'labels'              	=> $labels,
			'public'              	=> true,
			'publicly_queryable'  	=> true,
			'exclude_from_search' 	=> false,
			'show_ui'             	=> true,
			'show_in_menu'        	=> true,
			'menu_position'       	=> 22,
			'menu_icon'				=> 'dashicons-location',
			'capability_type'     	=> 'post',
			'hierarchical'        	=> false,
			'supports'            	=> array( 'title', 'editor' ),
			'has_archive'         	=> true,
			'rewrite'             	=> true,
			'query_var'           	=> true,
			'can_export'          	=> true
		);

		// Register the Post Type
		register_post_type( $this->type, $options );

	}


	/**
	* CPT Infos Messages
	*/  
	function add_messages ( $messages ) {

		global $post;
		$post_ID = $post->ID;      

		$messages[$this->type] = array(
			0 => '', 
			1 => sprintf( __( '%1$s updated. <a href="%2$s">See the %1$s</a>', 'lang_geoprojects' ), $this->single, esc_url( get_permalink( $post_ID ) ) ),
			2 => __( 'Custom field updated.', 'lang_geoprojects' ),
			3 => __( 'Custom field deleted.', 'lang_geoprojects' ),
			4 => sprintf( __( '%s updated.', 'lang_geoprojects' ), $this->single ),
			5 => isset($_GET['revision']) ? sprintf( __( '%1$s restored at revision %2$s', 'lang_geoprojects' ), $this->single, wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
			6 => sprintf( __( '%1$s published. <a href="%2$s">See the %1$s</a>', 'lang_geoprojects' ), $this->single, esc_url( get_permalink( $post_ID ) ) ),
			7 => sprintf( __( '%s saved', 'lang_geoprojects' ), $this->single ),
			8 => sprintf( '%1$s saved. <a target="_blank" href="%2$s">Preview the %1$s</a>', $this->single, esc_url( add_query_arg( 'preview', 'true', get_permalink( $post_ID ) ) ) ),
			9 => sprintf( '%1$s planned for the : <strong>%2$s</strong>. <a target="_blank" href="%3$s">Preview the %1$s</a>', $this->single, date_i18n( __( 'M j, Y @ G:i' ), strtotime( $post->post_date ) ), esc_url( get_permalink( $post_ID ) ) ),
			10 => sprintf( 'Draft of %1$s updates. <a target="_blank" href="%2$s">Preview the %1$s</a>', $this->single, esc_url( add_query_arg( 'preview', 'true', get_permalink( $post_ID ) ) ) ),
		);

		return $messages;
	}

}


/**
 * Init action for registering this CPT
 */
function gp_init_cpt_markers() {
	// Create class instance
	$cptMarkers = new gp_cpt_markers;

	// Register CPT
	$cptMarkers->add_post_type();

	// Register Messages
	add_filter( 'post_updated_messages', array( &$cptMarkers, 'add_messages' ) );
}

add_action( 'init', 'gp_init_cpt_markers' );