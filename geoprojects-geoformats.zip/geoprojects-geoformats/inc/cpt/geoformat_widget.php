<?php 
class geoformat_widget extends WP_Widget {
    function geoformat_widget() {
        parent::__construct(false, $name = 'Géoformats', array('description' => 'Liste des dernières publications. Latest posts.'));
    }
    function widget($args, $instance) { 
        extract( $args );
		$geoformat_widget_title = isset( $instance['geoformat_widget_title'] ) ? esc_attr( $instance['geoformat_widget_title'] ) : '';
	    $nr = isset( $instance['nr'] ) ? esc_attr( $instance['nr'] ) : '';
		?>
<div class="widget">
	<h3><?php echo $geoformat_widget_title; ?></h3>
		<div class="txtwidget">
			<ul>
				<?php
				  global $post;
				  $args = array( 'numberposts' => $nr, 'post_type' => array( 'geoformat' ) );
				  $myposts = get_posts( $args );
						foreach( $myposts as $post ) :  setup_postdata($post); ?>
							<li> <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a> </li>
				 <?php endforeach; ?>
			</ul>
		</div>
</div>
<?php
    }
    function update($new_instance, $old_instance) {
        return $new_instance;
    }
    function form($instance) {
		$geoformat_widget_title = isset( $instance['geoformat_widget_title'] ) ? esc_attr( $instance['geoformat_widget_title'] ) : '';
	    $nr = isset( $instance['nr'] ) ? esc_attr( $instance['nr'] ) : '';?>
            <p>
                <label for="<?php echo $this->get_field_id('geoformat_widget_title'); ?>"><?php _e('Title :', 'lang_geoprojects'); ?> </label>
                <input class="widefat" id="<?php echo $this->get_field_id('geoformat_widget_title'); ?>" name="<?php echo $this->get_field_name('geoformat_widget_title'); ?>" type="text" value="<?php echo esc_attr($geoformat_widget_title); ?>" />
            </p>
			<p>
                <label for="<?php echo $this->get_field_id('nr'); ?>"><?php _e('Nb of geoformat to display :', 'lang_geoprojects'); ?> </label>
                <input class="widefat" id="<?php echo $this->get_field_id('nr'); ?>" name="<?php echo $this->get_field_name('nr'); ?>" type="text" value="<?php echo esc_attr($nr); ?>" />
            </p>
        <?php       
    }
}
add_action('widgets_init', 'register_SLF_widget');
function register_SLF_widget() {
    register_widget('geoformat_widget');
}
?>