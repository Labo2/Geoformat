<?php
/*
Custom Post Type: Geoformat, d'après Simple Long Form
Äuthor: Laurence (at) OhMyBox.info
*/
//CPT Geoformat
function geoformat_create_post_type() {
  register_post_type( 'geoformat',
    array(
      'labels' => array(
        'name' => __( 'Geoformats', 'lang_geoprojects' ),
        'singular_name' => __( 'Geoformat', 'lang_geoprojects' ),
		'add_new' => __( 'Add New', 'lang_geoprojects' ),
        'add_new_item' => __( 'Add geoformat', 'lang_geoprojects' ),
        'edit_item' => __( 'Edit geoformat', 'lang_geoprojects' ),
        'new_item' => __( 'New geoformat', 'lang_geoprojects' ),
        'view_item' => __( 'View geoformat', 'lang_geoprojects' ),
        'search_items' => __( 'Search geoformat', 'lang_geoprojects' ),
        'not_found' => __( 'No geoformat found', 'lang_geoprojects' ),
        'not_found_in_trash' => __( 'No geoformat in trash', 'lang_geoprojects' ),
        'parent_item_colon' => __( 'Geoformat (parent) :', 'lang_geoprojects' )
      ),
      'public'              	=> true,
			'publicly_queryable'  	=> true,
			'exclude_from_search' 	=> false,
			'show_ui'             	=> true,
			'show_in_menu'        	=> true,
			'show_in_nav_menus'    	=> true,
			'capability_type'     	=> 'post',
			'hierarchical'        	=> false,
			'menu_position' 		=> 20,
			'has_archive'         	=> true,
			'query_var'           	=> true,
			'can_export'          	=> true,
			'menu_icon' 			=> 'dashicons-welcome-write-blog',
			'rewrite' => array('slug' => 'geoformat', 'with_front' => true),
			'supports' => array( 'title', 'thumbnail', 'revisions', 'tags', 'comments' )
    )
  );
}
add_action( 'init', 'geoformat_create_post_type' );

//Flush
register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );
register_activation_hook( __FILE__, 'geoformat_flush_rewrites' );
function geoformat_flush_rewrites() {
	geoformat_create_post_type();
	flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'flush_rewrite_rules' );

//Preview (debug)
add_filter('_wp_post_revision_fields', 'add_geoformat_debug_preview');
function add_geoformat_debug_preview($fields){
   $fields["debug_preview"] = "debug_preview";
   return $fields;
}

add_action( 'edit_form_after_title', 'geoformat_input_debug_preview' );
function geoformat_input_debug_preview() {
   echo '<input type="hidden" name="debug_preview" value="debug_preview">';
}

/**Intros**/
add_filter( 'get_the_excerpt', 'geoformat_excerpt' );
function geoformat_excerpt($excerpt) {
global $post;
	$chapo = get_post_meta( get_the_ID(), '_wp_editor_chapo', true );
	$meta_subline = get_post_meta( get_the_ID(), 'meta-subline', true );
		if( !empty( $chapo )  ) { 
			$excerpt = wp_strip_all_tags($chapo);
			return $excerpt;
		}
			else if( !empty( $meta_subline ) && empty( $chapo )  ) { 
			$excerpt = wp_strip_all_tags($meta_subline);
			return $excerpt;
		}
			else {
				return $excerpt;
			}
}

//METABOXES*************************************************//
add_action("add_meta_boxes", "add_geoformat_meta_box");
function add_geoformat_meta_box() {
    add_meta_box("geoformat-meta-box", "Settings", "geoformat_meta_callback", "geoformat", "side", "high", null);
}

function geoformat_custom_meta() {
    add_meta_box( 'geoformat_meta', __( 'Settings', 'geoformat' ), 'geoformat_meta_callback', 'geoformat' );
}

function geoformat_meta_callback( $post ) {
    wp_nonce_field( basename( __FILE__ ), 'geoformat_nonce' );
    $geoformat_stored_meta = get_post_meta( $post->ID );
?>

<div id="wrap">
<h4 class="nav-tab-wrapper">	 
<a href="#" class="nav-tab navtab1 active1"> <?php _e( 'General', 'lang_geoprojects' ); ?> </a>	 
<a href="#" class="nav-tab navtab2 active2"> <?php _e( 'Intro', 'lang_geoprojects' ); ?> </a>	 
<a href="#" class="nav-tab navtab3 active3"> <?php _e( 'Navbars', 'lang_geoprojects' ); ?> </a> 
</h4> 

<div id="tab1" class="ui-sortable meta-box-sortables">	
	
	<p>		
	<label for="meta-font-size" class="geoformat-font-size"><?php _e( 'Text size', 'lang_geoprojects' )?></label>		
	<br/>
	<select name="meta-font-size" id="meta-font-size">
		<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['meta-font-size'] ) ) selected( $geoformat_stored_meta['meta-font-size'][0], 'select-one' ); ?>><?php _e( 'Medium', 'lang_geoprojects' )?></option>';
		<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['meta-font-size'] ) ) selected( $geoformat_stored_meta['meta-font-size'][0], 'select-two' ); ?>><?php _e( 'Large', 'lang_geoprojects' )?></option>';			
		<option value="select-three" <?php if ( isset ( $geoformat_stored_meta['meta-font-size'] ) ) selected( $geoformat_stored_meta['meta-font-size'][0], 'select-three' ); ?>><?php _e( 'Small', 'lang_geoprojects' )?></option>';			
	</select>	
	</p>

	<p>		
	<label for="meta-col" class="geoformat-col"><?php _e( 'Main column width', 'lang_geoprojects' )?></label>
	<br/>		
	<select name="meta-col" id="meta-col">			
		<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['meta-col'] ) ) selected( $geoformat_stored_meta['meta-col'][0], 'select-one' ); ?>><?php _e( 'Medium', 'lang_geoprojects' )?></option>';			
		<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['meta-col'] ) ) selected( $geoformat_stored_meta['meta-col'][0], 'select-two' ); ?>><?php _e( 'Large', 'lang_geoprojects' )?></option>';			
		<option value="select-three" <?php if ( isset ( $geoformat_stored_meta['meta-col'] ) ) selected( $geoformat_stored_meta['meta-col'][0], 'select-three' ); ?>><?php _e( 'Small', 'lang_geoprojects' )?></option>';			
	</select>	
	</p>
	<p>
	<label for="quote-design" class="quote-design"><?php _e( 'Quotes border', 'lang_geoprojects' )?></label>			
	<select name="quote-design" id="quote-design">				
		<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['quote-design'] ) ) selected( $geoformat_stored_meta['quote-design'][0], 'select-one' ); ?>><?php _e( 'Left border', 'lang_geoprojects' )?></option>';				
		<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['quote-design'] ) ) selected( $geoformat_stored_meta['quote-design'][0], 'select-two' ); ?>><?php _e( 'Right border', 'lang_geoprojects' )?></option>';				
		<option value="select-three" <?php if ( isset ( $geoformat_stored_meta['quote-design'] ) ) selected( $geoformat_stored_meta['quote-design'][0], 'select-three' ); ?>><?php _e( 'Bottom border', 'lang_geoprojects' )?></option>';					
		<option value="select-four" <?php if ( isset ( $geoformat_stored_meta['quote-design'] ) ) selected( $geoformat_stored_meta['quote-design'][0], 'select-four' ); ?>><?php _e( 'Framed', 'lang_geoprojects' )?></option>';				
	</select>	
	</p>			
	
	<p>		
	<label for="quote" class="quote"><?php _e( 'Quotes border type', 'lang_geoprojects' )?></label>		
	<select name="quote" id="quote">				
		<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['quote'] ) ) selected( $geoformat_stored_meta['quote'][0], 'select-one' ); ?>><?php _e( 'Primary color', 'lang_geoprojects' )?></option>';				
		<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['quote'] ) ) selected( $geoformat_stored_meta['quote'][0], 'select-two' ); ?>><?php _e( 'Primary color dotted', 'lang_geoprojects' )?></option>';				
		<option value="select-three" <?php if ( isset ( $geoformat_stored_meta['quote'] ) ) selected( $geoformat_stored_meta['quote'][0], 'select-three' ); ?>><?php _e( 'Light Grey', 'lang_geoprojects' )?></option>';					
		<option value="select-four" <?php if ( isset ( $geoformat_stored_meta['quote'] ) ) selected( $geoformat_stored_meta['quote'][0], 'select-four' ); ?>><?php _e( 'Light Grey dotted', 'lang_geoprojects' )?></option>';					
	</select>	
	</p>
</div>

<div id="tab2" class="ui-sortable meta-box-sortables" style="display:none;">		 
	<div id="introt">
		
		<h3 class="geoformat-txt"><?php _e('Page loading', 'lang_geoprojects');?></h3>
		<p>
		<label for="load-auteur" class="load-auteur"><?php _e( 'Display the author\'s name', 'lang_geoprojects' )?></label>		
			<select name="load-auteur" id="load-auteur">				
				<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['load-auteur'] ) ) selected( $geoformat_stored_meta['load-auteur'][0], 'select-one' ); ?>><?php _e( 'Yes', 'lang_geoprojects' )?></option>';				
				<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['load-auteur'] ) ) selected( $geoformat_stored_meta['load-auteur'][0], 'select-two' ); ?>><?php _e( 'No', 'lang_geoprojects' )?></option>';				
			</select>
		</p>				

		<p>			
		<label for="meta-loader" class="geoformat-loader-animate"><?php _e( 'Loader', 'lang_geoprojects' )?></label>			
		<br/>			
		<select name="meta-loader" id="meta-loader">				
			<option value="select-three" <?php if ( isset ( $geoformat_stored_meta['meta-loader'] ) ) selected( $geoformat_stored_meta['meta-loader'][0], 'select-three' ); ?>><?php _e( 'Circle', 'lang_geoprojects' )?></option>';					
			<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['meta-loader'] ) ) selected( $geoformat_stored_meta['meta-loader'][0], 'select-two' ); ?>><?php _e( 'Bar', 'lang_geoprojects' )?></option>';				
		</select>		
		</p>

		<p>			
		<label for="meta-loader-animate" class="geoformat-loader-animate"><?php _e('Loader animation', 'lang_geoprojects' ); ?></label>			
		<br/>			
		<select name="meta-loader-animate" id="meta-loader-animate">				
			<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['meta-loader-animate'] ) ) selected( $geoformat_stored_meta['meta-loader-animate'][0], 'select-one' ); ?>><?php _e( 'Faded', 'lang_geoprojects' )?></option>';				
			<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['meta-loader-animate'] ) ) selected( $geoformat_stored_meta['meta-loader-animate'][0], 'select-two' ); ?>><?php _e( 'Animated', 'lang_geoprojects' )?></option>';				
		</select>		
		</p>
	</div>		

	<p>
	<label for="meta-animate" class="geoformat-animate"><?php _e( 'Intro effect', 'lang_geoprojects' )?></label>			
	<br/>			
	<select name="meta-animate" id="meta-animate">				
		<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['meta-animate'] ) ) selected( $geoformat_stored_meta['meta-animate'][0], 'select-one' ); ?>><?php _e( 'Jump', 'lang_geoprojects' )?></option>';				
		<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['meta-animate'] ) ) selected( $geoformat_stored_meta['meta-animate'][0], 'select-two' ); ?>><?php _e( 'Push', 'lang_geoprojects' )?></option>';				
	</select>
	</p>		 
	
	<p>			
	<label for="meta-trigger" class="geoformat-trigger"><?php _e( 'Trigger Button', 'lang_geoprojects' )?></label>			
		<br/>			
	<select name="meta-trigger" id="meta-trigger">					
		<option value="select-three" <?php if ( isset ( $geoformat_stored_meta['meta-trigger'] ) ) selected( $geoformat_stored_meta['meta-trigger'][0], 'select-three' ); ?>><?php _e( 'Arrow (regular)', 'lang_geoprojects' )?></option>';
		<option value="select-four" <?php if ( isset ( $geoformat_stored_meta['meta-trigger'] ) ) selected( $geoformat_stored_meta['meta-trigger'][0], 'select-four' ); ?>><?php _e( 'Arrow (regular) with border', 'lang_geoprojects' )?></option>';
		<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['meta-trigger'] ) ) selected( $geoformat_stored_meta['meta-trigger'][0], 'select-two' ); ?>><?php _e( 'Arrow (bold)', 'lang_geoprojects' )?></option>';
		<option value="select-five" <?php if ( isset ( $geoformat_stored_meta['meta-trigger'] ) ) selected( $geoformat_stored_meta['meta-trigger'][0], 'select-five' ); ?>><?php _e( 'Arrow (bold) with border', 'lang_geoprojects' )?></option>';
		<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['meta-trigger'] ) ) selected( $geoformat_stored_meta['meta-trigger'][0], 'select-one' ); ?>><?php _e( 'Text', 'lang_geoprojects' )?></option>';			
	</select>		
	</p>		
	
	<div id="trigger-mes" style="display:none;">			
	<p>
	<label for="meta-trigger" class="geoformat-trigger"><?php _e( 'Trigger Button text', 'lang_geoprojects' )?></label>			
	<br/>			
	<input type="text" name="trigger-text" id="trigger-text" class="trigger-text" placeholder="<?php _e('Ex. : Read more', 'lang_geoprojects');?>" value="<?php if ( isset ( $geoformat_stored_meta['trigger-text'] ) ) : $trigger = $geoformat_stored_meta['trigger-text'][0]; echo $trigger; endif; ?>" />		
	</div>				
		<?php if( !empty($trigger) )  : ?>		
			<style>#trigger-mes{display:block!important;}</style>				
		<?php endif; ?>
</div>	
	
	<div id="tab3" class="ui-sortable meta-box-sortables" style="display:none;">		
	
	<p>
		<label for="meta-bar" class="meta-bar"><?php _e( 'Progress bar position', 'lang_geoprojects' )?></label>		
		<br/>
		<select name="meta-bar" id="meta-bar">
			<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['meta-bar'] ) ) selected( $geoformat_stored_meta['meta-bar'][0], 'select-one' ); ?>><?php _e( 'Top', 'lang_geoprojects' )?></option>';
			<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['meta-bar'] ) ) selected( $geoformat_stored_meta['meta-bar'][0], 'select-two' ); ?>><?php _e( 'Bottom', 'lang_geoprojects' )?></option>';			
			<option value="select-three" <?php if ( isset ( $geoformat_stored_meta['meta-bar'] ) ) selected( $geoformat_stored_meta['meta-bar'][0], 'select-three' ); ?>><?php _e( 'No progress bar', 'lang_geoprojects' )?></option>';			
		</select>
	</p>
	
	<div id="bar">
	<h3 class="geoformat-txt"><?php _e('Fixed navbar', 'lang_geoprojects');?></h3>	
	<p>
		<label for="bar-sup" class="bar-sup"><?php _e( 'Position', 'lang_geoprojects' )?></label>		
		<br/>
		<select name="bar-sup" id="bar-sup">
			<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['bar-sup'] ) ) selected( $geoformat_stored_meta['bar-sup'][0], 'select-one' ); ?>><?php _e( 'Top of the page', 'lang_geoprojects' )?></option>';
			<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['bar-sup'] ) ) selected( $geoformat_stored_meta['bar-sup'][0], 'select-two' ); ?>><?php _e( 'Bottom of the page', 'lang_geoprojects' )?></option>';			
		</select>
	</p>
	<p>	
	<label for="top-bar" class="top-bar"><?php _e( 'Background color', 'lang_geoprojects' )?></label>		
	<select name="top-bar" id="top-bar">				
		<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['top-bar'] ) ) selected( $geoformat_stored_meta['top-bar'][0], 'select-one' ); ?>><?php _e( 'Primary color', 'lang_geoprojects' )?></option>';				
		<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['top-bar'] ) ) selected( $geoformat_stored_meta['top-bar'][0], 'select-two' ); ?>><?php _e( 'White', 'lang_geoprojects' )?></option>';				
		<option value="select-three" <?php if ( isset ( $geoformat_stored_meta['top-bar'] ) ) selected( $geoformat_stored_meta['top-bar'][0], 'select-three' ); ?>><?php _e( 'Black', 'lang_geoprojects' )?></option>';			
	</select>	
	</p>		
	
	<p>	
	<label for="reseaux" class="reseaux"><?php _e( 'Social networks icons', 'lang_geoprojects' )?></label>		
	<select name="reseaux" id="reseaux">				
		<option value="select-four" <?php if ( isset ( $geoformat_stored_meta['reseaux'] ) ) selected( $geoformat_stored_meta['reseaux'][0], 'select-four' ); ?>><?php _e( 'White', 'lang_geoprojects' )?></option>';			
		<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['reseaux'] ) ) selected( $geoformat_stored_meta['reseaux'][0], 'select-one' ); ?>><?php _e( 'Primary color (positive)', 'lang_geoprojects' )?></option>';				
		<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['reseaux'] ) ) selected( $geoformat_stored_meta['reseaux'][0], 'select-two' ); ?>><?php _e( 'Primary color (negative)', 'lang_geoprojects' )?></option>';				
		<option value="select-three" <?php if ( isset ( $geoformat_stored_meta['reseaux'] ) ) selected( $geoformat_stored_meta['reseaux'][0], 'select-three' ); ?>><?php _e( 'Original colors', 'lang_geoprojects' )?></option>';			
		</select>	
	</p>		
		
	<p>	
		<label for="burger" class="burger"><?php _e( 'Navigation inside the page', 'lang_geoprojects' )?></label>		
		<select name="burger" id="burger">				
			<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['burger'] ) ) selected( $geoformat_stored_meta['burger'][0], 'select-one' ); ?>><?php _e( 'Section titles', 'lang_geoprojects' )?></option>';				
			<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['burger'] ) ) selected( $geoformat_stored_meta['burger'][0], 'select-two' ); ?>><?php _e( 'Circles', 'lang_geoprojects' )?></option>';				
		</select>	
	</p>
		<p>
		<label for="bar-title" class="bar-title"><?php _e( 'Display the title', 'lang_geoprojects' )?></label>		
		<br/>
		<select name="bar-title" id="bar-title">
			<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['bar-title'] ) ) selected( $geoformat_stored_meta['bar-title'][0], 'select-one' ); ?>><?php _e( 'Yes', 'lang_geoprojects' )?></option>';
			<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['bar-title'] ) ) selected( $geoformat_stored_meta['bar-title'][0], 'select-two' ); ?>><?php _e( 'No', 'lang_geoprojects' )?></option>';			
		</select>
	</p>
	</div>		

	</div>
</div>
	<?php
}

//Extra scripts
function geoformat_color_enqueue() {
    global $typenow;
    if( $typenow == 'geoformat' ) {
        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_script( 'geoformat-box-color-js', get_template_directory_uri() . 'js/admin/box-color.js', array( 'wp-color-picker' ) );
    }
}
add_action( 'admin_enqueue_scripts', 'geoformat_color_enqueue' );

function geoformat_meta_save( $post_id ) {     
$is_autosave = wp_is_post_autosave( $post_id );    
$is_revision = wp_is_post_revision( $post_id );    
$is_valid_nonce = ( isset( $_POST[ 'geoformat_nonce' ] ) && wp_verify_nonce( $_POST[ 'geoformat_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';
    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
    }	
		if( isset( $_POST[ 'meta-col' ] ) ) {			
			update_post_meta( $post_id, 'meta-col', sanitize_text_field($_POST[ 'meta-col' ]) );		
		} if( isset( $_POST[ 'meta-font-size' ] ) ) {			
			update_post_meta( $post_id, 'meta-font-size', sanitize_text_field($_POST[ 'meta-font-size' ]) );		
		}	if( isset( $_POST[ 'meta-bar' ] ) ) {			
			update_post_meta( $post_id, 'meta-bar', sanitize_text_field($_POST[ 'meta-bar' ]) );		
		}	if( isset( $_POST[ 'meta-animate' ] ) ) {			
			update_post_meta( $post_id, 'meta-animate', sanitize_text_field($_POST[ 'animate' ]) );		
		}	if( isset( $_POST[ 'meta-loader' ] ) ) {			
			update_post_meta( $post_id, 'meta-loader', sanitize_text_field($_POST[ 'meta-loader' ]) );		
		}	if( isset( $_POST[ 'meta-loader-animate' ] ) ) {			
			update_post_meta( $post_id, 'meta-loader-animate', sanitize_text_field($_POST[ 'meta-loader-animate' ]) );		
		}	if( isset( $_POST[ 'meta-trigger' ] ) ) {			
			update_post_meta( $post_id, 'meta-trigger', sanitize_text_field($_POST[ 'meta-trigger' ]) );		
		}	if( isset( $_POST[ 'trigger-text' ] ) ) {			
			update_post_meta( $post_id, 'trigger-text', sanitize_text_field($_POST[ 'trigger-text' ]) );		
		}	if( isset( $_POST[ 'load-auteur' ] ) ) {			
			update_post_meta( $post_id, 'load-auteur', sanitize_text_field($_POST[ 'load-auteur' ]) );		
		}	if( isset( $_POST[ 'top-bar' ] ) ) {			
			update_post_meta( $post_id, 'top-bar', sanitize_text_field($_POST[ 'top-bar' ]) );		
		}	if( isset( $_POST[ 'bar-sup' ] ) ) {			
			update_post_meta( $post_id, 'bar-sup', sanitize_text_field($_POST[ 'bar-sup' ]) );		
		}	if( isset( $_POST[ 'bar-title' ] ) ) {			
			update_post_meta( $post_id, 'bar-title', sanitize_text_field($_POST[ 'bar-title' ]) );		
		}   if( isset( $_POST[ 'reseaux' ] ) ) {			
			update_post_meta( $post_id, 'reseaux', sanitize_text_field($_POST[ 'reseaux' ]) );		
		}	if( isset( $_POST[ 'quote' ] ) ) {			
			update_post_meta( $post_id, 'quote', sanitize_text_field($_POST[ 'quote' ]) );		
		}	if( isset( $_POST[ 'quote-design' ] ) ) {			
			update_post_meta( $post_id, 'quote-design', sanitize_text_field($_POST[ 'quote-design' ]) );		
		}	if( isset( $_POST[ 'burger' ] ) ) {			
			update_post_meta( $post_id, 'burger', sanitize_text_field($_POST[ 'burger' ]) );		
		}
}
add_action( 'save_post', 'geoformat_meta_save' );

//Sections
function geoformat_add_custom_box() {
	
		  add_meta_box( 'wp_editor_chapo', 'Intro', 'wp_editor_chapo', 'geoformat', 'normal', 'core' );
		  add_meta_box( 'wp_editor_section_1', 'Section 1', 'wp_editor_meta_box', 'geoformat', 'normal', 'core' );
		  add_meta_box( 'wp_editor_section_2', 'Section 2', 'wp_editor_meta_box_2', 'geoformat', 'normal', 'core' );
		  add_meta_box( 'wp_editor_section_3', 'Section 3', 'wp_editor_meta_box_3', 'geoformat', 'normal', 'core' );
		  add_meta_box( 'wp_editor_section_4', 'Section 4', 'wp_editor_meta_box_4', 'geoformat', 'normal', 'core' );;
		  add_meta_box( 'wp_editor_section_5', 'Section 5', 'wp_editor_meta_box_5', 'geoformat', 'normal', 'core' );		  
		  add_meta_box( 'wp_editor_footer', 'Footer', 'wp_editor_footer', 'geoformat', 'normal', 'core' );
		
}
add_action( 'add_meta_boxes', 'geoformat_add_custom_box' );

//Chapo
function wp_editor_chapo( $post ) {wp_nonce_field( plugin_basename( __FILE__ ), 'geoformat_nonce' );$geoformat_stored_meta = get_post_meta( $post->ID );
?>
    <p>
        <label for="meta-auteur" class="geoformat-auteur"><?php _e( 'Author', 'lang_geoprojects' )?></label>
        <input type="text" name="meta-auteur" class="meta-text-title" id="meta-auteur" value="<?php if ( isset ( $geoformat_stored_meta['meta-auteur'] ) ) echo $geoformat_stored_meta['meta-auteur'][0]; ?>" />
    </p>
	<p>
        <label for="meta-photos" class="geoformat-photos"><?php _e( 'Author of the images', 'lang_geoprojects' )?></label>
        <input type="text" name="meta-photos" class="meta-text-title" id="meta-photos" value="<?php if ( isset ( $geoformat_stored_meta['meta-photos'] ) ) echo $geoformat_stored_meta['meta-photos'][0]; ?>" />
    </p>
	<p>
        <label for="meta-subline" class="geoformat-subline"><?php _e( 'Subtitle', 'lang_geoprojects' )?></label>
        <textarea type="text" name="meta-subline" class="meta-text-title" id="meta_subline" /><?php if ( isset ( $geoformat_stored_meta['meta-subline'] ) ) echo $geoformat_stored_meta['meta-subline'][0]; ?></textarea>
    </p>
	<p>
		<label for="section_title_align" class="geoformat-font_title"><?php _e( 'Title alignment', 'lang_geoprojects' )?></label>
		<br/>
			<select name="section_title_align" id="section_title_align" class="options">
				<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['section_title_align'] ) ) selected( $geoformat_stored_meta['section_title_align'][0], 'select-one' ); ?>><?php _e( 'Center',  'lang_geoprojects' )?></option>';
				<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['section_title_align'] ) ) selected( $geoformat_stored_meta['section_title_align'][0], 'select-two' ); ?>><?php _e( 'Left', 'lang_geoprojects' )?></option>';				
				<option value="select-three" <?php if ( isset ( $geoformat_stored_meta['section_title_align'] ) ) selected( $geoformat_stored_meta['section_title_align'][0], 'select-three' ); ?>><?php _e( 'Right', 'lang_geoprojects' )?></option>';				
			</select>
	</p>
	<p>
		<label for="section_title_color" class="geoformat-font_title"><?php _e( 'Title color', 'lang_geoprojects' )?></label>
		<br/>
			<select name="section_title_color" id="section_title_color" class="options">
				<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['section_title_color'] ) ) selected( $geoformat_stored_meta['section_title_color'][0], 'select-one' ); ?>><?php _e( 'White',  'lang_geoprojects' )?></option>';
				<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['section_title_color'] ) ) selected( $geoformat_stored_meta['section_title_color'][0], 'select-two' ); ?>><?php _e( 'Black', 'lang_geoprojects' )?></option>';				
				<option value="select-three" <?php if ( isset ( $geoformat_stored_meta['section_title_color'] ) ) selected( $geoformat_stored_meta['section_title_color'][0], 'select-three' ); ?>><?php _e( 'White with primary color background', 'lang_geoprojects' )?></option>';
				<option value="select-four" <?php if ( isset ( $geoformat_stored_meta['section_title_color'] ) ) selected( $geoformat_stored_meta['section_title_color'][0], 'select-four' ); ?>><?php _e( 'White on black', 'lang_geoprojects' )?></option>';
			</select>
	</p>
	<p>
	<label for="meta-date" class="geoformat-date"><?php _e( 'Display published date', 'lang_geoprojects' )?></label>			
	<br/>			
	<select name="meta-date" id="meta-date">				
		<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['meta-date'] ) ) selected( $geoformat_stored_meta['meta-date'][0], 'select-one' ); ?>><?php _e( 'Yes', 'lang_geoprojects' )?></option>';				
		<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['meta-date'] ) ) selected( $geoformat_stored_meta['meta-date'][0], 'select-two' ); ?>><?php _e( 'No', 'lang_geoprojects' )?></option>';				
	</select>
	</p>
	<p>
		<label for="meta-image" class="lang_geoprojects-title"><?php _e( 'Background image (intro)', 'lang_geoprojects' )?></label>
		<br/>
			<input type="text" class="meta-image" name="meta-image" id="meta-image" value="<?php if ( isset ( $geoformat_stored_meta['meta-image'] ) ) : $topimg = $geoformat_stored_meta['meta-image'][0]; echo $topimg; endif; ?>" />
			<input type="button" id="meta-image-button" class="button-slf" value="<?php _e( 'Select your image', 'lang_geoprojects' )?>" />
		<br/>			
			
			<?php if( !empty( $topimg ) ): ?>			
				<div class="img-slf" id="img-slf">
					<img src="<?php echo $topimg; ?>" id="imgtop" />
						<p class="remove_img" id="remove_img">
							<a title="<?php _e('Remove', 'lang_geoprojects'); ?>" href="javascript:;" id="remove-footer-thumbnail"><?php _e('Remove the image', 'lang_geoprojects'); ?></a>
						</p>			
				</div>
			<?php endif; ?>
	</p>
	<p>
		<label for="meta-map" class="geoformat-map"><?php _e( 'OR map in the background (copy-paste the embed code available at the bottom of the map (share button)', 'lang_geoprojects' )?></label>
		<br/>
		<input type="text" class="meta-text-title" name="meta-map" id="meta-map" value="<?php if ( isset ( $geoformat_stored_meta['meta-map'] ) ) echo $geoformat_stored_meta['meta-map'][0]; ?>" />
	</p>
	<p>
		<label for="meta-video" class="geoformat-video"><?php _e( 'OR video in the background (copy-paste your embed code)', 'lang_geoprojects' )?></label>
		<br/>
		<input type="text" class="meta-text-title" name="meta-video" id="meta-video" value="<?php if ( isset ( $geoformat_stored_meta['meta-video'] ) ) echo $geoformat_stored_meta['meta-video'][0]; ?>" />
	</p>
	<hr />
	<h2 class="title-content"><?php _e('Add content (lead)', 'lang_geoprojects'); ?></h2>	
	<?php 
	
	$field_value = get_post_meta( $post->ID, '_wp_editor_chapo', false );
	
	if ( $field_value == false ) :
		wp_editor( ' ', '_wp_editor_chapo' );
	else :
		wp_editor( $field_value[0], '_wp_editor_chapo' ); 
	endif;
	?>
	
	<h2 class="title-content"><?php _e('Add text (optional)', 'lang_geoprojects'); ?></h2>
	<?php	  
	$field_value = get_post_meta( $post->ID, '_wp_editor_text', false );	  
	
	if ( $field_value == false ) :
		wp_editor( ' ', '_wp_editor_text' );
	else :
		wp_editor( $field_value[0], '_wp_editor_text' ); 
	endif;	  
	
	$post1 = get_post_meta( get_the_ID(), '_wp_editor_section_1', true ); 
		if( empty( $post1 ) ) { ?>		
			<div id="add1" class="add"> 
				<?php _e( 'Ad a new section +', 'lang_geoprojects' )?>
			</div>		
			<?php } else { ?>
			<style>
			#wp_editor_section_1{display:block;}
			#add1{display:none;}
			</style>
	<?php }
}
function geoformat_save_postdata_intro( $post_id ) {
	$is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'geoformat_nonce' ] ) && wp_verify_nonce( $_POST[ 'geoformat_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';
    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {        return;    }
		$meta_subline = '';
		if( isset( $_POST[ 'meta-subline' ] ) ) {			
			$meta_subline = update_post_meta( $post_id, 'meta-subline', sanitize_text_field($_POST[ 'meta-subline' ]) );
		}
		$meta_auteur = '';
		if( isset( $_POST[ 'meta-auteur' ] ) ) {			
			$meta_auteur = update_post_meta( $post_id, 'meta-auteur', sanitize_text_field($_POST[ 'meta-auteur' ]) );		}		
		$meta_photos = '';
		if( isset( $_POST[ 'meta-photos' ] ) ) {
			$meta_photos = update_post_meta( $post_id, 'meta-photos', sanitize_text_field($_POST[ 'meta-photos' ]) );
		}
		$meta_image = '';
		if( isset( $_POST[ 'meta-image' ] ) ) {
			$meta_image = update_post_meta( $post_id, 'meta-image', sanitize_text_field($_POST[ 'meta-image' ]) );
		}
		if( isset( $_POST[ 'meta-date' ] ) ) {
			update_post_meta( $post_id, 'meta-date', sanitize_text_field($_POST[ 'meta-date' ]) );
		}
		if( isset( $_POST[ 'meta-video' ] ) ) {
			update_post_meta( $post_id, 'meta-video', htmlentities(stripslashes($_POST[ 'meta-video' ])) );
		}
		if( isset( $_POST[ 'meta-map' ] ) ) {
			update_post_meta( $post_id, 'meta-map', htmlentities(stripslashes($_POST[ 'meta-map' ])) );
		}
		if( isset( $_POST[ 'section_title_color' ] ) ) {			
			update_post_meta( $post_id, 'section_title_color', sanitize_text_field($_POST[ 'section_title_color' ]) );		
		}
		if( isset( $_POST[ 'section_title_align' ] ) ) {			
			update_post_meta( $post_id, 'section_title_align', sanitize_text_field($_POST[ 'section_title_align' ]) );		
			}   		
		$meta_chapo = '';
		if ( isset ( $_POST['_wp_editor_chapo'] ) ) {		
			$meta_chapo = update_post_meta( $post_id, '_wp_editor_chapo', $_POST['_wp_editor_chapo'] );	 
		}
		if ( isset ( $_POST['_wp_editor_text'] ) ) {		
			update_post_meta( $post_id, '_wp_editor_text', $_POST['_wp_editor_text'] );	 
		}
}
add_action( 'save_post', 'geoformat_save_postdata_intro' );

//Section 1
function wp_editor_meta_box( $post ) { 
	wp_nonce_field( basename( __FILE__ ), 'geoformat_nonce' );
    $geoformat_stored_meta = get_post_meta( $post->ID );	
	?>		
	<p>
        <label for="meta-title_1" class="geoformat-title"><?php _e( 'Section title', 'lang_geoprojects' )?></label>
        <input type="text" name="meta-title_1" id="meta-text-title1" class="meta-text-title" value="<?php if ( isset ( $geoformat_stored_meta['meta-title_1'] ) ) echo $geoformat_stored_meta['meta-title_1'][0]; ?>" />
    </p>
	<p>
        <label for="meta-align_1" class="geoformat-align"><?php _e( 'Title alignment', 'lang_geoprojects' )?></label>
        <br/>
		<select name="section1_title_align" id="section1_title_align" class="options">
			<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['section1_title_align'] ) ) selected( $geoformat_stored_meta['section1_title_align'][0], 'select-one' ); ?>><?php _e( 'Left',  'lang_geoprojects' )?></option>';
			<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['section1_title_align'] ) ) selected( $geoformat_stored_meta['section1_title_align'][0], 'select-two' ); ?>><?php _e( 'Center', 'lang_geoprojects' )?></option>';
			<option value="select-three" <?php if ( isset ( $geoformat_stored_meta['section1_title_align'] ) ) selected( $geoformat_stored_meta['section1_title_align'][0], 'select-three' ); ?>><?php _e( 'Right', 'lang_geoprojects' )?></option>';
		</select>
	</p>
	<p>
		<label for="section1_title_color" class="geoformat-font_title"><?php _e( 'Title color', 'lang_geoprojects' )?></label>
		<br/>
		<select name="section1_title_color" id="section1_title_color" class="options">
			<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['section1_title_color'] ) ) selected( $geoformat_stored_meta['section1_title_color'][0], 'select-one' ); ?>><?php _e( 'White',  'lang_geoprojects' )?></option>';
			<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['section1_title_color'] ) ) selected( $geoformat_stored_meta['section1_title_color'][0], 'select-two' ); ?>><?php _e( 'Black', 'lang_geoprojects' )?></option>';
			<option value="select-three" <?php if ( isset ( $geoformat_stored_meta['section1_title_color'] ) ) selected( $geoformat_stored_meta['section1_title_color'][0], 'select-three' ); ?>><?php _e( 'White with primary color background', 'lang_geoprojects' )?></option>';
			<option value="select-four" <?php if ( isset ( $geoformat_stored_meta['section1_title_color'] ) ) selected( $geoformat_stored_meta['section1_title_color'][0], 'select-four' ); ?>><?php _e( 'White on black', 'lang_geoprojects' )?></option>';
		</select>
	</p>
	<p>
		<label for="meta-image_1" class="lang_geoprojects-title"><?php _e( 'Background image (section\'s intro)', 'lang_geoprojects' )?></label>
		<br/>
			<input type="text" class="meta-image" name="meta-image_1" id="meta-image_1" value="<?php if ( isset ( $geoformat_stored_meta['meta-image_1'] ) ) : $topimg_1 = $geoformat_stored_meta['meta-image_1'][0]; echo $topimg_1; endif; ?>" />
			<input type="button" id="meta-image-button_1" class="button-slf" value="<?php _e( 'Select your image', 'lang_geoprojects' )?>" />
		<br/>			
			
			<?php if( !empty( $topimg_1 ) ): ?>			
				<div class="img-slf" id="img-slf_1">
					<img src="<?php echo $topimg_1; ?>" id="imgtop1" />
						<p class="remove_img" id="remove_img_1">
							<a title="<?php _e('Remove', 'lang_geoprojects'); ?>" href="javascript:;" id="remove-footer-thumbnail"><?php _e('Remove the image', 'lang_geoprojects'); ?></a>
						</p>			
				</div>
			<?php endif; ?>
	</p>
	<p>
        <label for="section1_caption" class="geoformat-title"><?php _e( 'Image caption', 'lang_geoprojects' )?></label>
        <input type="text" name="section1_caption" id="section1_caption" class="meta-text-title" value="<?php if ( isset ( $geoformat_stored_meta['section1_caption'] ) ) echo $geoformat_stored_meta['section1_caption'][0]; ?>" />
    </p>
	<p>
		<label for="meta-map_1" class="geoformat-map"><?php _e( 'OR map in the background (copy-paste the embed code available at the bottom of the map (share button)', 'lang_geoprojects' )?></label>
		<br/>
		<input type="text" class="meta-text-title" name="meta-map_1" id="meta-map_1" value="<?php if ( isset ( $geoformat_stored_meta['meta-map_1'] ) ) echo $geoformat_stored_meta['meta-map_1'][0]; ?>" />
	</p>
	<p>
		<label for="meta-video_1" class="geoformat-video"><?php _e( 'OR video in the background (copy-paste your embed code)', 'lang_geoprojects' )?></label>
		<br/>
		<input type="text" style="width:100%;" class="meta-video_1" name="meta-video_1" id="meta-video_1" value="<?php if ( isset ( $geoformat_stored_meta['meta-video_1'] ) ) echo $geoformat_stored_meta['meta-video_1'][0]; ?>" />
	</p>
	<hr/>
	<h2 class="title-content"><?php _e('Add content', 'lang_geoprojects'); ?></h2>

	<?php	

		$field_value = get_post_meta( $post->ID, '_wp_editor_section_1', false );
		
		if ( $field_value == false ) :
			wp_editor( ' ', '_wp_editor_section_1' );
		else :
			wp_editor( $field_value[0], '_wp_editor_section_1' ); 
		endif;
		
		$post2 = get_post_meta( get_the_ID(), '_wp_editor_section_2', true ); 

			if( empty( $post2 ) ) { ?>
		<div id="add2" class="add">
		<?php _e( 'Ad a new section +', 'lang_geoprojects' )?></div>
	
	<?php } else { ?>
		<style>
		#wp_editor_section_2{display:block;}
		#add2{display:none;}
		</style>

	<?php }
}

function geoformat_save_postdata_1( $post_id ) {

	$is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'geoformat_nonce' ] ) && wp_verify_nonce( $_POST[ 'geoformat_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';

    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
    }

	  if( isset( $_POST[ 'meta-title_1' ] ) ) {
			update_post_meta( $post_id, 'meta-title_1', sanitize_text_field( $_POST[ 'meta-title_1' ] ) );
		}

		if( isset( $_POST[ 'section1_title_color' ] ) ) {
			update_post_meta( $post_id, 'section1_title_color', $_POST[ 'section1_title_color' ] );
		}

		if( isset( $_POST[ 'section1_title_align' ] ) ) {
			update_post_meta( $post_id, 'section1_title_align', sanitize_text_field($_POST[ 'section1_title_align' ]) );
		}

	  if( isset( $_POST[ 'meta-image_1' ] ) ) {
		update_post_meta( $post_id, 'meta-image_1', sanitize_text_field($_POST[ 'meta-image_1' ]) );
	  }
	  if( isset( $_POST[ 'meta-map_1' ] ) ) {
			update_post_meta( $post_id, 'meta-map_1', htmlentities(stripslashes($_POST[ 'meta-map_1' ])) );
		}
	  if( isset( $_POST[ 'meta-video_1' ] ) ) {
			update_post_meta( $post_id, 'meta-video_1', htmlentities(stripslashes($_POST[ 'meta-video_1' ])) );
		}

	  if( isset( $_POST[ 'section1_caption' ] ) ) {
			update_post_meta( $post_id, 'section1_caption', sanitize_text_field( $_POST[ 'section1_caption' ] ) );
		}

	  if ( isset ( $_POST['_wp_editor_section_1'] ) ) {

		update_post_meta( $post_id, '_wp_editor_section_1', $_POST['_wp_editor_section_1'] );
	  }
}

add_action( 'save_post', 'geoformat_save_postdata_1' );

//Section 2

function wp_editor_meta_box_2( $post ) { 

	wp_nonce_field( basename( __FILE__ ), 'geoformat_nonce' );
    $geoformat_stored_meta = get_post_meta( $post->ID );
?> 

	<p>
        <label for="meta-title_2" class="geoformat-title"><?php _e( 'Section title', 'lang_geoprojects' )?></label>
        <input type="text" name="meta-title_2" id="meta-text-title_2" class="meta-text-title" value="<?php if ( isset ( $geoformat_stored_meta['meta-title_2'] ) ) echo $geoformat_stored_meta['meta-title_2'][0]; ?>" />
    </p>

	<p>
        <label for="meta-align_2" class="geoformat-align"><?php _e( 'Title alignment', 'lang_geoprojects' )?></label>
        <br/>
			<select name="section2_title_align" id="section2_title_align" class="options">
				<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['section2_title_align'] ) ) selected( $geoformat_stored_meta['section2_title_align'][0], 'select-one' ); ?>><?php _e( 'Left',  'lang_geoprojects' )?></option>';
				<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['section2_title_align'] ) ) selected( $geoformat_stored_meta['section2_title_align'][0], 'select-two' ); ?>><?php _e( 'Center', 'lang_geoprojects' )?></option>';
				<option value="select-three" <?php if ( isset ( $geoformat_stored_meta['section2_title_align'] ) ) selected( $geoformat_stored_meta['section2_title_align'][0], 'select-three' ); ?>><?php _e( 'Right', 'lang_geoprojects' )?></option>';
			</select>
	</p>

	<p>
		<label for="section2_title_color" class="geoformat-font_title"><?php _e( 'Title color', 'lang_geoprojects' )?></label>
		<br/>
		<select name="section2_title_color" id="section2_title_color" class="options">
			<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['section2_title_color'] ) ) selected( $geoformat_stored_meta['section2_title_color'][0], 'select-one' ); ?>><?php _e( 'White',  'lang_geoprojects' )?></option>';
			<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['section2_title_color'] ) ) selected( $geoformat_stored_meta['section2_title_color'][0], 'select-two' ); ?>><?php _e( 'Black', 'lang_geoprojects' )?></option>';
			<option value="select-three" <?php if ( isset ( $geoformat_stored_meta['section2_title_color'] ) ) selected( $geoformat_stored_meta['section2_title_color'][0], 'select-three' ); ?>><?php _e( 'White with primary color background', 'lang_geoprojects' )?></option>';
			<option value="select-four" <?php if ( isset ( $geoformat_stored_meta['section2_title_color'] ) ) selected( $geoformat_stored_meta['section2_title_color'][0], 'select-four' ); ?>><?php _e( 'White on black', 'lang_geoprojects' )?></option>';
		</select>
	</p>

	<p>
		<label for="meta-image_2" class="lang_geoprojects-row-title"><?php _e( 'Background image', 'lang_geoprojects' )?></label>
			<br/>
			<input type="text" class="meta-image" name="meta-image_2" id="meta-image_2" value="<?php if ( isset ( $geoformat_stored_meta['meta-image_2'] ) ) : $topimg_2 = $geoformat_stored_meta['meta-image_2'][0]; echo $topimg_2; endif; ?>" />
			<input type="button" id="meta-image-button_2" class="button-slf" value="<?php _e( 'Select your image', 'lang_geoprojects' )?>" />
		<br/>			
			
			<?php if( !empty( $topimg_2 ) ): ?>			
				<div class="img-slf" id="img-slf_2">
					<img src="<?php echo $topimg_2; ?>" id="imgtop2" />
						<p class="remove_img" id="remove_img_2">
							<a title="<?php _e('Remove', 'lang_geoprojects'); ?>" href="javascript:;" id="remove-footer-thumbnail"><?php _e('Remove the image', 'lang_geoprojects'); ?></a>
						</p>			
				</div>
			<?php endif; ?>

	</p>

	<p>
        <label for="section2_caption" class="geoformat-title"><?php _e( 'Image caption', 'lang_geoprojects' )?></label>
        <input type="text" name="section2_caption" id="section2_caption" class="meta-text-title" value="<?php if ( isset ( $geoformat_stored_meta['section2_caption'] ) ) echo $geoformat_stored_meta['section2_caption'][0]; ?>" />
    </p>
	
	<p>
		<label for="meta-map_2" class="geoformat-map"><?php _e( 'OR map in the background (copy-paste the embed code available at the bottom of the map (share button)', 'lang_geoprojects' )?></label>
		<br/>
		<input type="text" class="meta-text-title" name="meta-map_2" id="meta-map_2" value="<?php if ( isset ( $geoformat_stored_meta['meta-map_2'] ) ) echo $geoformat_stored_meta['meta-map_2'][0]; ?>" />
	</p>
	
	<p>
		<label for="meta-video_2" class="geoformat-video"><?php _e( 'OR video in the background (copy-paste your embed code)', 'lang_geoprojects' )?></label>
		<br/>
		<input type="text" style="width:100%;" class="meta-video_2" name="meta-video_2" id="meta-video_2" value="<?php if ( isset ( $geoformat_stored_meta['meta-video_2'] ) ) echo $geoformat_stored_meta['meta-video_2'][0]; ?>" />
	</p>

	<hr/>

	<h2 class="title-content"><?php _e('Add content', 'lang_geoprojects'); ?></h2>

	<?php
		$field_value = get_post_meta( $post->ID, '_wp_editor_section_2', false );
		
		if ( $field_value == false ) :
			wp_editor( ' ', '_wp_editor_section_2' );
		else :
			wp_editor( $field_value[0], '_wp_editor_section_2' ); 
		endif;
		
		$post3 = get_post_meta( get_the_ID(), '_wp_editor_section_3', true ); 

		if( empty( $post3 ) ) { ?>
		<div id="add3" class="add"> <?php _e( 'Ad a new section +', 'lang_geoprojects' )?></div>
	
	<?php } else { ?>
		<style>
		#wp_editor_section_3{display:block;}
		#add3{display:none;}
		</style>

	<?php }
}

function geoformat_save_postdata_2( $post_id ) {

	$is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'geoformat_nonce' ] ) && wp_verify_nonce( $_POST[ 'geoformat_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';

 
    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
    }

		if( isset( $_POST[ 'meta-title_2' ] ) ) {
			update_post_meta( $post_id, 'meta-title_2', sanitize_text_field( $_POST[ 'meta-title_2' ] ) );
		}

		if( isset( $_POST[ 'section2_title_align' ] ) ) {
			update_post_meta( $post_id, 'section2_title_align', $_POST[ 'section2_title_align' ] );
		}

		if( isset( $_POST[ 'section2_title_color' ] ) ) {
			update_post_meta( $post_id, 'section2_title_color', $_POST[ 'section2_title_color' ] );
		}
		if( isset( $_POST[ 'meta-map_2' ] ) ) {
			update_post_meta( $post_id, 'meta-map_2', htmlentities(stripslashes($_POST[ 'meta-map_2' ])) );
		}
		
		if( isset( $_POST[ 'meta-image_2' ] ) ) {
			update_post_meta( $post_id, 'meta-image_2', $_POST[ 'meta-image_2' ] );
		}
		if( isset( $_POST[ 'meta-video_2' ] ) ) {
			update_post_meta( $post_id, 'meta-video_2', htmlentities(stripslashes($_POST[ 'meta-video_2' ])) );
		}
		if( isset( $_POST[ 'section2_caption' ] ) ) {
			update_post_meta( $post_id, 'section2_caption', sanitize_text_field( $_POST[ 'section2_caption' ] ) );
		}
		if ( isset ( $_POST['_wp_editor_section_2'] ) ) {
			update_post_meta( $post_id, '_wp_editor_section_2', $_POST['_wp_editor_section_2'] );
	  }
}
add_action( 'save_post', 'geoformat_save_postdata_2' );

//Section 3

function wp_editor_meta_box_3( $post ) { 
	wp_nonce_field( basename( __FILE__ ), 'geoformat_nonce' );
    $geoformat_stored_meta = get_post_meta( $post->ID );
?> 

	<p>
        <label for="meta-title_3" class="geoformat-title"><?php _e( 'Section title', 'lang_geoprojects' )?></label>
        <input type="text" name="meta-title_3" id="meta-text-title_3" class="meta-text-title" value="<?php if ( isset ( $geoformat_stored_meta['meta-title_3'] ) ) echo $geoformat_stored_meta['meta-title_3'][0]; ?>" />
    </p>

	<p>
        <label for="meta-align_3" class="geoformat-align"><?php _e( 'Title alignment', 'lang_geoprojects' )?></label>
        <br/>
			<select name="section3_title_align" id="section3_title_align" class="options">
				<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['section3_title_align'] ) ) selected( $geoformat_stored_meta['section3_title_align'][0], 'select-one' ); ?>><?php _e( 'Left',  'lang_geoprojects' )?></option>';
				<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['section3_title_align'] ) ) selected( $geoformat_stored_meta['section3_title_align'][0], 'select-two' ); ?>><?php _e( 'Center', 'lang_geoprojects' )?></option>';
				<option value="select-three" <?php if ( isset ( $geoformat_stored_meta['section3_title_align'] ) ) selected( $geoformat_stored_meta['section3_title_align'][0], 'select-three' ); ?>><?php _e( 'Right', 'lang_geoprojects' )?></option>';
			</select>
	</p>

	<p>
		<label for="section3_title_color" class="geoformat-font_title"><?php _e( 'Title color', 'lang_geoprojects' )?></label>
		<br/>
			<select name="section3_title_color" id="section3_title_color" class="options">
				<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['section3_title_color'] ) ) selected( $geoformat_stored_meta['section3_title_color'][0], 'select-one' ); ?>><?php _e( 'White',  'lang_geoprojects' )?></option>';
				<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['section3_title_color'] ) ) selected( $geoformat_stored_meta['section3_title_color'][0], 'select-two' ); ?>><?php _e( 'Black', 'lang_geoprojects' )?></option>';
				<option value="select-three" <?php if ( isset ( $geoformat_stored_meta['section3_title_color'] ) ) selected( $geoformat_stored_meta['section3_title_color'][0], 'select-three' ); ?>><?php _e( 'White with primary color background', 'lang_geoprojects' )?></option>';
				<option value="select-four" <?php if ( isset ( $geoformat_stored_meta['section3_title_color'] ) ) selected( $geoformat_stored_meta['section3_title_color'][0], 'select-four' ); ?>><?php _e( 'White on black', 'lang_geoprojects' )?></option>';
			</select>
	</p>

	<p>
		<label for="meta-image_3" class="lang_geoprojects-row-title"><?php _e( 'Background image', 'lang_geoprojects' )?></label>
		<br/>
			<input type="text" class="meta-image" name="meta-image_3" id="meta-image_3" value="<?php if ( isset ( $geoformat_stored_meta['meta-image_3'] ) ) : $topimg_3 = $geoformat_stored_meta['meta-image_3'][0]; echo $topimg_3; endif; ?>" />
			<input type="button" id="meta-image-button_3" class="button-slf" value="<?php _e( 'Select your image', 'lang_geoprojects' )?>" />
		<br/>			
			
			<?php if( !empty( $topimg_3 ) ): ?>			
				<div class="img-slf" id="img-slf_3">
					<img src="<?php echo $topimg_3; ?>" id="imgtop3" />
						<p class="remove_img" id="remove_img_3">
							<a title="<?php _e('Remove', 'lang_geoprojects'); ?>" href="javascript:;" id="remove-footer-thumbnail"><?php _e('Remove the image', 'lang_geoprojects'); ?></a>
						</p>			
				</div>
			<?php endif; ?>
	</p>

	<p>
        <label for="section3_caption" class="geoformat-title"><?php _e( 'Image caption', 'lang_geoprojects' )?></label>
        <input type="text" name="section3_caption" id="section3_caption" class="meta-text-title" value="<?php if ( isset ( $geoformat_stored_meta['section3_caption'] ) ) echo $geoformat_stored_meta['section3_caption'][0]; ?>" />
    </p>
	
	<p>
		<label for="meta-map_3" class="geoformat-map"><?php _e( 'OR map in the background (copy-paste the embed code available at the bottom of the map (share button)', 'lang_geoprojects' )?></label>
		<br/>
		<input type="text" class="meta-text-title" name="meta-map_3" id="meta-map_3" value="<?php if ( isset ( $geoformat_stored_meta['meta-map_3'] ) ) echo $geoformat_stored_meta['meta-map_3'][0]; ?>" />
	</p>
	
	<p>
		<label for="meta-video_3" class="geoformat-video"><?php _e( 'OR video in the background (copy-paste your embed code)', 'lang_geoprojects' )?></label>
		<br/>
		<input type="text" style="width:100%;" class="meta-video_3" name="meta-video_3" id="meta-video_3" value="<?php if ( isset ( $geoformat_stored_meta['meta-video_3'] ) ) echo $geoformat_stored_meta['meta-video_3'][0]; ?>" />
	</p>

	<hr/>
	
	<h3 class="title-content2"><?php _e('Add content', 'lang_geoprojects'); ?></h3>
 
	<?php
		$field_value = get_post_meta( $post->ID, '_wp_editor_section_3', false );
		
		if ( $field_value == false ) :
			wp_editor( ' ', '_wp_editor_section_3' );
		else :
			wp_editor( $field_value[0], '_wp_editor_section_3' ); 
		endif;
	  
		$post4 = get_post_meta( get_the_ID(), '_wp_editor_section_4', true ); 

		if( empty( $post4 ) ) { ?>
		<div id="add4" class="add"> <?php _e( 'Ad a new section +', 'lang_geoprojects' )?></div>
	
	<?php } else { ?>
		<style>
		#wp_editor_section_4{display:block;}
		#add4{display:none;}
		</style>

	<?php }
}

function geoformat_save_postdata_3( $post_id ) {

	$is_autosave = wp_is_post_autosave( $post_id );

    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'geoformat_nonce' ] ) && wp_verify_nonce( $_POST[ 'geoformat_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';

     if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
     }

	 if( isset( $_POST[ 'meta-title_3' ] ) ) {
			update_post_meta( $post_id, 'meta-title_3', sanitize_text_field( $_POST[ 'meta-title_3' ] ) );
		}
		
	if( isset( $_POST[ 'section3_title_align' ] ) ) {
			update_post_meta( $post_id, 'section3_title_align', $_POST[ 'section3_title_align' ] );
		}

	 if( isset( $_POST[ 'section3_title_color' ] ) ) {
			update_post_meta( $post_id, 'section3_title_color', $_POST[ 'section3_title_color' ] );
	 }

	 if( isset( $_POST[ 'meta-image_3' ] ) ) {
		update_post_meta( $post_id, 'meta-image_3', $_POST[ 'meta-image_3' ] );
	 }
	 if( isset( $_POST[ 'meta-map_3' ] ) ) {
			update_post_meta( $post_id, 'meta-map_3', htmlentities(stripslashes($_POST[ 'meta-map_3' ])) );
		}
	  if( isset( $_POST[ 'meta-video_3' ] ) ) {
			update_post_meta( $post_id, 'meta-video_3', htmlentities(stripslashes($_POST[ 'meta-video_3' ])) );
		}

	  if( isset( $_POST[ 'section3_caption' ] ) ) {
			update_post_meta( $post_id, 'section3_caption', sanitize_text_field( $_POST[ 'section3_caption' ] ) );
		}

	 if ( isset ( $_POST['_wp_editor_section_3'] ) ) {
	update_post_meta( $post_id, '_wp_editor_section_3', $_POST['_wp_editor_section_3'] );
	  }
}

add_action( 'save_post', 'geoformat_save_postdata_3' );

//Section 4

function wp_editor_meta_box_4( $post ) { 

	wp_nonce_field( basename( __FILE__ ), 'geoformat_nonce' );
    $geoformat_stored_meta = get_post_meta( $post->ID );
?> 
	<p>
        <label for="meta-title_4" class="geoformat-title"><?php _e( 'Section title', 'lang_geoprojects' )?></label>
        <input type="text" name="meta-title_4" id="meta-text-title_4" class="meta-text-title" value="<?php if ( isset ( $geoformat_stored_meta['meta-title_4'] ) ) echo $geoformat_stored_meta['meta-title_4'][0]; ?>" />
    </p>

	<p>

        <label for="meta-align_4" class="geoformat-align"><?php _e( 'Title alignment', 'lang_geoprojects' )?></label>
        <br/>
			<select name="section4_title_align" id="section4_title_align" class="options">
				<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['section4_title_align'] ) ) selected( $geoformat_stored_meta['section4_title_align'][0], 'select-one' ); ?>><?php _e( 'Left',  'lang_geoprojects' )?></option>';
				<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['section4_title_align'] ) ) selected( $geoformat_stored_meta['section4_title_align'][0], 'select-two' ); ?>><?php _e( 'Center', 'lang_geoprojects' )?></option>';
				<option value="select-three" <?php if ( isset ( $geoformat_stored_meta['section4_title_align'] ) ) selected( $geoformat_stored_meta['section4_title_align'][0], 'select-three' ); ?>><?php _e( 'Right', 'lang_geoprojects' )?></option>';
			</select>
	</p>

	<p>
		<label for="section4_title_color" class="geoformat-font_title"><?php _e( 'Title color', 'lang_geoprojects' )?></label>
		<br/>
		<select name="section4_title_color" id="section4_title_color" class="options">
			<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['section4_title_color'] ) ) selected( $geoformat_stored_meta['section4_title_color'][0], 'select-one' ); ?>><?php _e( 'White',  'lang_geoprojects' )?></option>';
			<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['section4_title_color'] ) ) selected( $geoformat_stored_meta['section4_title_color'][0], 'select-two' ); ?>><?php _e( 'Black', 'lang_geoprojects' )?></option>';
			<option value="select-three" <?php if ( isset ( $geoformat_stored_meta['section4_title_color'] ) ) selected( $geoformat_stored_meta['section4_title_color'][0], 'select-three' ); ?>><?php _e( 'White with primary color background', 'lang_geoprojects' )?></option>';
			<option value="select-four" <?php if ( isset ( $geoformat_stored_meta['section4_title_color'] ) ) selected( $geoformat_stored_meta['section4_title_color'][0], 'select-four' ); ?>><?php _e( 'White on black', 'lang_geoprojects' )?></option>';
			
		</select>
	</p>

	<p>
		<label for="meta-image_4" class="lang_geoprojects-row-title"><?php _e( 'Background image', 'lang_geoprojects' )?></label>
		<br/>
			<input type="text" class="meta-image" name="meta-image_4" id="meta-image_4" value="<?php if ( isset ( $geoformat_stored_meta['meta-image_4'] ) ) : $topimg_4 = $geoformat_stored_meta['meta-image_4'][0]; echo $topimg_4; endif; ?>" />
			<input type="button" id="meta-image-button_4" class="button-slf" value="<?php _e( 'Select your image', 'lang_geoprojects' )?>" />
		<br/>			
			
			<?php if( !empty( $topimg_4 ) ): ?>			
				<div class="img-slf" id="img-slf_4">
					<img src="<?php echo $topimg_4; ?>" id="imgtop4" />
						<p class="remove_img" id="remove_img_4">
							<a title="<?php _e('Remove', 'lang_geoprojects'); ?>" href="javascript:;" id="remove-footer-thumbnail"><?php _e('Remove the image', 'lang_geoprojects'); ?></a>
						</p>			
				</div>
			<?php endif; ?>

	</p>

	<p>
        <label for="section4_caption" class="geoformat-title"><?php _e( 'Image caption', 'lang_geoprojects' )?></label>
        <input type="text" name="section4_caption" id="section4_caption" class="meta-text-title" value="<?php if ( isset ( $geoformat_stored_meta['section4_caption'] ) ) echo $geoformat_stored_meta['section4_caption'][0]; ?>" />
    </p>
	
	<p>
		<label for="meta-map_4" class="geoformat-map"><?php _e( 'OR map in the background (copy-paste the embed code available at the bottom of the map (share button)', 'lang_geoprojects' )?></label>
		<br/>
		<input type="text" class="meta-text-title" name="meta-map_4" id="meta-map_4" value="<?php if ( isset ( $geoformat_stored_meta['meta-map_4'] ) ) echo $geoformat_stored_meta['meta-map_4'][0]; ?>" />
	</p>
	
	<p>
		<label for="meta-video_4" class="geoformat-video"><?php _e( 'OR video in the background (copy-paste your embed code)', 'lang_geoprojects' )?></label>
		<br/>
		<input type="text" style="width:100%;" class="meta-video_4" name="meta-video_4" id="meta-video_4" value="<?php if ( isset ( $geoformat_stored_meta['meta-video_4'] ) ) echo $geoformat_stored_meta['meta-video_4'][0]; ?>" />
	</p>

	<hr/>

	<h3 class="title-content2"><?php _e('Add content', 'lang_geoprojects'); ?></h3>

	<?php
		$field_value = get_post_meta( $post->ID, '_wp_editor_section_4', false );
		
		if ( $field_value == false ) :
			wp_editor( ' ', '_wp_editor_section_4' );
		else :
			wp_editor( $field_value[0], '_wp_editor_section_4' ); 
		endif;
		
		$post5 = get_post_meta( get_the_ID(), '_wp_editor_section_5', true ); 

		if( empty( $post5 ) ) { ?>
		<div id="add5" class="add"> <?php _e( 'Ad a new section +', 'lang_geoprojects' )?></div>
	
	<?php } else { ?>
		<style>
		#wp_editor_section_5{display:block;}
		#add5{display:none;}
		</style>

	<?php }
}

function geoformat_save_postdata_4( $post_id ) {

	$is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'geoformat_nonce' ] ) && wp_verify_nonce( $_POST[ 'geoformat_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';

    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
    }

		if( isset( $_POST[ 'meta-title_4' ] ) ) {
			update_post_meta( $post_id, 'meta-title_4', sanitize_text_field( $_POST[ 'meta-title_4' ] ) );
		}
		if( isset( $_POST[ 'section4_title_color' ] ) ) {
			update_post_meta( $post_id, 'section4_title_color', $_POST[ 'section4_title_color' ] );
		}
		if( isset( $_POST[ 'section4_title_align' ] ) ) {
			update_post_meta( $post_id, 'section4_title_align', $_POST[ 'section4_title_align' ] );
		}
		if( isset( $_POST[ 'meta-image_4' ] ) ) {
			update_post_meta( $post_id, 'meta-image_4', $_POST[ 'meta-image_4' ] );
		}
		if( isset( $_POST[ 'section4_caption' ] ) ) {
			update_post_meta( $post_id, 'section4_caption', sanitize_text_field( $_POST[ 'section4_caption' ] ) );
		}
		if( isset( $_POST[ 'meta-map_4' ] ) ) {
			update_post_meta( $post_id, 'meta-map_4', htmlentities(stripslashes($_POST[ 'meta-map_4' ])) );
		}
		if( isset( $_POST[ 'meta-video_4' ] ) ) {
			update_post_meta( $post_id, 'meta-video_4', htmlentities(stripslashes($_POST[ 'meta-video_4' ])) );
		}
		if ( isset ( $_POST['_wp_editor_section_4'] ) ) {
			update_post_meta( $post_id, '_wp_editor_section_4', $_POST['_wp_editor_section_4'] );
		}
}
add_action( 'save_post', 'geoformat_save_postdata_4' );

//Section 5

function wp_editor_meta_box_5( $post ) { 

	wp_nonce_field( basename( __FILE__ ), 'geoformat_nonce' );
    $geoformat_stored_meta = get_post_meta( $post->ID );

?> 
	<p>
        <label for="meta-title_5" class="geoformat-title"><?php _e( 'Section title', 'lang_geoprojects' )?></label>
        <input type="text" name="meta-title_5" id="meta-text-title_5" class="meta-text-title" value="<?php if ( isset ( $geoformat_stored_meta['meta-title_5'] ) ) echo $geoformat_stored_meta['meta-title_5'][0]; ?>" />
    </p>

	<p>
        <label for="meta-align_5" class="geoformat-align"><?php _e( 'Title alignment', 'lang_geoprojects' )?></label>
        <br/>
			<select name="section5_title_align" id="section5_title_align" class="options">
				<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['section5_title_align'] ) ) selected( $geoformat_stored_meta['section5_title_align'][0], 'select-one' ); ?>><?php _e( 'Left',  'lang_geoprojects' )?></option>';
				<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['section5_title_align'] ) ) selected( $geoformat_stored_meta['section5_title_align'][0], 'select-two' ); ?>><?php _e( 'Center', 'lang_geoprojects' )?></option>';
				<option value="select-three" <?php if ( isset ( $geoformat_stored_meta['section5_title_align'] ) ) selected( $geoformat_stored_meta['section5_title_align'][0], 'select-three' ); ?>><?php _e( 'Right', 'lang_geoprojects' )?></option>';
			</select>
	</p>

	<p>
		<label for="section5_title_color" class="geoformat-font_title"><?php _e( 'Title color', 'lang_geoprojects' )?></label>
		<br/>
			<select name="section5_title_color" id="section5_title_color" class="options">
				<option value="select-one" <?php if ( isset ( $geoformat_stored_meta['section5_title_color'] ) ) selected( $geoformat_stored_meta['section5_title_color'][0], 'select-one' ); ?>><?php _e( 'White',  'lang_geoprojects' )?></option>';
				<option value="select-two" <?php if ( isset ( $geoformat_stored_meta['section5_title_color'] ) ) selected( $geoformat_stored_meta['section5_title_color'][0], 'select-two' ); ?>><?php _e( 'Black', 'lang_geoprojects' )?></option>';
				<option value="select-three" <?php if ( isset ( $geoformat_stored_meta['section5_title_color'] ) ) selected( $geoformat_stored_meta['section5_title_color'][0], 'select-three' ); ?>><?php _e( 'White on primary color', 'lang_geoprojects' )?></option>';
				<option value="select-four" <?php if ( isset ( $geoformat_stored_meta['section5_title_color'] ) ) selected( $geoformat_stored_meta['section5_title_color'][0], 'select-four' ); ?>><?php _e( 'White on black', 'lang_geoprojects' )?></option>';
			</select>
	</p>

	<p>
		<label for="meta-image_5" class="lang_geoprojects-row-title"><?php _e( 'Background image', 'lang_geoprojects' )?></label>
			<br/>
		<input type="text" class="meta-image" name="meta-image_5" id="meta-image_5" value="<?php if ( isset ( $geoformat_stored_meta['meta-image_5'] ) ) : $topimg_5 = $geoformat_stored_meta['meta-image_5'][0]; echo $topimg_5; endif; ?>" />
			<input type="button" id="meta-image-button_5" class="button-slf" value="<?php _e( 'Select your image', 'lang_geoprojects' )?>" />
		<br/>			
			
			<?php if( !empty( $topimg_5 ) ): ?>			
				<div class="img-slf" id="img-slf_5">
					<img src="<?php echo $topimg_5; ?>" id="imgtop5" />
						<p class="remove_img" id="remove_img_5">
							<a title="<?php _e('Remove', 'lang_geoprojects'); ?>" href="javascript:;" id="remove-footer-thumbnail"><?php _e('Remove the image', 'lang_geoprojects'); ?></a>
						</p>			
				</div>
			<?php endif; ?>
	</p>

	<p>
        <label for="section5_caption" class="geoformat-title"><?php _e( 'Image caption', 'lang_geoprojects' )?></label>
        <input type="text" name="section5_caption" id="section5_caption" class="meta-text-title" value="<?php if ( isset ( $geoformat_stored_meta['section5_caption'] ) ) echo $geoformat_stored_meta['section5_caption'][0]; ?>" />
    </p>
	
	<p>
		<label for="meta-map_5" class="geoformat-map"><?php _e( 'OR map in the background (copy-paste the embed code available at the bottom of the map (share button)', 'lang_geoprojects' )?></label>
		<br/>
		<input type="text" class="meta-text-title" name="meta-map_5" id="meta-map_5" value="<?php if ( isset ( $geoformat_stored_meta['meta-map_5'] ) ) echo $geoformat_stored_meta['meta-map_5'][0]; ?>" />
	</p>
	
	<p>
		<label for="meta-video_5" class="geoformat-video"><?php _e( 'OR video in the background (copy-paste your embed code)', 'lang_geoprojects' )?></label>
		<br/>
		<input type="text" style="width:100%;" class="meta-video_5" name="meta-video_5" id="meta-video_5" value="<?php if ( isset ( $geoformat_stored_meta['meta-video_5'] ) ) echo $geoformat_stored_meta['meta-video_5'][0]; ?>" />
	</p>

	<hr/>

	<h3 class="title-content2"><?php _e('Add content', 'lang_geoprojects'); ?></h3>

	<?php

		$field_value = get_post_meta( $post->ID, '_wp_editor_section_5', false );
		
		if ( $field_value == false ) :
			wp_editor( ' ', '_wp_editor_section_5' );
		else :
			wp_editor( $field_value[0], '_wp_editor_section_5' ); 
		endif;
}

function geoformat_save_postdata_5( $post_id ) {

	$is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'geoformat_nonce' ] ) && wp_verify_nonce( $_POST[ 'geoformat_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';

    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
    }

		if( isset( $_POST[ 'meta-title_5' ] ) ) {
			update_post_meta( $post_id, 'meta-title_5', sanitize_text_field( $_POST[ 'meta-title_5' ] ) );
		}

		if( isset( $_POST[ 'section5_title_color' ] ) ) {
			update_post_meta( $post_id, 'section5_title_color', $_POST[ 'section5_title_color' ] );
		}

		if( isset( $_POST[ 'section5_title_align' ] ) ) {
			update_post_meta( $post_id, 'section5_title_align', $_POST[ 'section5_title_align' ] );
		}
		
		if( isset( $_POST[ 'meta-image_5' ] ) ) {
			update_post_meta( $post_id, 'meta-image_5', $_POST[ 'meta-image_5' ] );
		}
		if( isset( $_POST[ 'meta-map_5' ] ) ) {
			update_post_meta( $post_id, 'meta-map_5', htmlentities(stripslashes($_POST[ 'meta-map_5' ])) );
		}
		if( isset( $_POST[ 'meta-video_5' ] ) ) {
			update_post_meta( $post_id, 'meta-video_5', htmlentities(stripslashes($_POST[ 'meta-video_5' ])) );
		}
		if( isset( $_POST[ 'section5_caption' ] ) ) {
			update_post_meta( $post_id, 'section5_caption', sanitize_text_field( $_POST[ 'section5_caption' ] ) );
		}
		if ( isset ( $_POST['_wp_editor_section_5'] ) ) {
			update_post_meta( $post_id, '_wp_editor_section_5', $_POST['_wp_editor_section_5'] );
		}
}
add_action( 'save_post', 'geoformat_save_postdata_5' );

//Footer Metabox
function wp_editor_footer( $post ) { 
	wp_nonce_field( basename( __FILE__ ), 'geoformat_nonce' );
    $geoformat_stored_meta = get_post_meta( $post->ID );
?> 

	<h2 class="title-content"><?php _e('Add content', 'lang_geoprojects'); ?></h2>

	<?php	
		$field_value = get_post_meta( $post->ID, '_wp_editor_foot', false );
		
		if ( $field_value == false ) :
			wp_editor( ' ', '_wp_editor_foot' );
		else :
			wp_editor( $field_value[0], '_wp_editor_foot' ); 
		endif;
	?>
	 <p>
        <label for="custom-css" class="geoformat-subline"><?php _e( 'Additional style (advanced user)', 'lang_geoprojects' )?></label>
        
		<?php if ( isset ( $geoformat_stored_meta['custom-css'] ) ) { ?><textarea type="text" name="custom-css" class="meta-text-css" id="custom_css" /><?php echo $geoformat_stored_meta['custom-css'][0]; ?></textarea>
		<?php } else { ?><textarea type="text" name="custom-css" class="meta-text-css" id="custom_css" /></textarea>
		<?php } ?>
	</p>
	
<?php }

function geoformat_save_postdata_foot( $post_id ) {
	$is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'geoformat_nonce' ] ) && wp_verify_nonce( $_POST[ 'geoformat_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';
		if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
			return;
		}
		  if ( isset ( $_POST['_wp_editor_foot'] ) ) {
			update_post_meta( $post_id, '_wp_editor_foot', $_POST['_wp_editor_foot'] );
		  }
		  if ( isset ( $_POST['custom-css'] ) ) {
			update_post_meta( $post_id, 'custom-css', $_POST['custom-css'] );
		  }
}
add_action( 'save_post', 'geoformat_save_postdata_foot' );

function geoformat_feed_request($qv) {
	if (isset($qv['feed']) && !isset($qv['post_type']))
	$qv['post_type'] = array('post', 'geoformat');
	return $qv;
}
add_filter('request', 'geoformat_feed_request');

function geoformat_dashboard_view() {

?>

   <ul>

     <?php

          global $post;

		   $args = array( 'numberposts' => 5, 'post_type' => array( 'geoformat' ) );

          $myposts = get_posts( $args );

                foreach( $myposts as $post ) :  setup_postdata($post); ?>
                    <li><span style="padding-right:10px;width:150px;"><?php the_time('d M, G') ?> : <?php the_time('i'); ?></span>
					<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
          <?php endforeach; ?>
   </ul>
<?php
}
function add_geoformat_dashboard_view() {
       wp_add_dashboard_widget( 'geoformat_dashboard_view', __( 'Published geoformats', 'lang_geoprojects' ), 'geoformat_dashboard_view' );
}
add_action('wp_dashboard_setup', 'add_geoformat_dashboard_view' );

//Editory styles
//Editor
if ( ! function_exists( 'geoformat_style_select' ) ) {
	function geoformat_style_select( $buttons ) {
		array_push( $buttons, 'styleselect' );
		return $buttons;
	}
}
add_filter( 'mce_buttons', 'geoformat_style_select' );

if ( ! function_exists( 'geoformat_styles_dropdown' ) ) {
	function geoformat_styles_dropdown( $settings ) {

		$new_styles = array(
					array(
						'title'		=> __('Button','lang_geoprojects'),
						'inline'	=> 'button',
						'classes'	=> 'btn-slf'
					),
					array(
						'title'		=> __('Dropcap','lang_geoprojects'),
						'inline'	=> 'span',
						'classes'	=> 'dropcap',
					),
					array(
						'title'		=> __('Framed (white background)','lang_geoprojects'),
						'block'	=> 'div',
						'classes'	=> 'panel',
					),
					array(
						'title'		=> __('Framed (grey background)','lang_geoprojects'),
						'block'	=> 'div',
						'classes'	=> 'well',
					),
					array(
						'title'		=> __('Framed (primary color)','lang_geoprojects'),
						'block'	=> 'div',
						'classes'	=> 'jumbotron',
					)
		);

		$settings['style_formats_merge'] = false;
		$settings['style_formats'] = json_encode( $new_styles );
		return $settings;
	}
}
add_filter( 'tiny_mce_before_init', 'geoformat_styles_dropdown' );

add_filter( 'mce_css', 'slf_editor_style' );
function slf_editor_style( $mce_css ){   
    $mce_css = get_template_directory_uri() . '/css/editor-style.css';
    return $mce_css;
}

//Slider Gallery
if ( function_exists( 'add_image_size' ) ) {
add_image_size( 'geoformat_gallery_size', 600, 600,  array( 'left', 'top' )  ); 
}
add_filter('image_size_names_choose', 'geoformat_image_sizes');

function geoformat_image_sizes($sizes) {
$addsizes = array(
"geoformat_gallery_size" => __('Geoformat','lang_geoprojects')
);
$newsizes = array_merge($sizes, $addsizes);
return $newsizes;
}

add_shortcode('geoformatslide', 'geoformat_slider_gallery');

function geoformat_slider_gallery($attr) {
	$post = get_post();
	static $instance = 0;
	$instance++;
	$attr['columns'] = 1;
	$attr['size'] = 'full';
	$attr['link'] = 'file';
	$attr['orderby'] = 'post__in';
	$attr['include'] = $attr['ids'];		

	$output = apply_filters('post_gallery', '', $attr);

	if ( $output != '' )
		return $output;

	if ( isset( $attr['orderby'] ) ) {
		$attr['orderby'] = sanitize_sql_orderby( $attr['orderby'] );
		if ( !$attr['orderby'] )
			unset( $attr['orderby'] );
	}

	extract(shortcode_atts(array(
		'order'      => 'ASC',
		'orderby'    => 'menu_order ID',
		'id'         => $post->ID,
		'gallerytag'    => 'div',
		'itemtag'    => 'div',
		'icontag'    => 'div',
		'captiontag' => 'p',
		'columns'    => 1,
		'size'       => 'thumbnail',
		'include'    => '',
		'exclude'    => ''

	), $attr));

	$id = intval($id);

	if ( 'RAND' == $order )

		$orderby = 'none';

	if ( !empty($include) ) {

		$_attachments = get_posts( array('include' => $include, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );

		$attachments = array();

		foreach ( $_attachments as $key => $val ) {

			$attachments[$val->ID] = $_attachments[$key];
		}

	} elseif ( !empty($exclude) ) {
		$attachments = get_children( array('post_parent' => $id, 'exclude' => $exclude, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );

	} else {
		$attachments = get_children( array('post_parent' => $id, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );
	}



	if ( empty($attachments) )

		return '';

	$gallery_style = $gallery_div = '';

	if ( apply_filters( 'use_default_gallery_style', false ) )

		$gallery_style = " ";

	$gallery_div = "<div class='carousel-inner' role='listbox'>";
	$output = apply_filters( 'gallery_style', $gallery_style . "\n\t\t" . $gallery_div );
	$n = 0;

	foreach ( $attachments as $id => $attachment ) {

		$link = wp_get_attachment_link($id, 'full', true, false);

		$output .= "<div class='item'>";

		$output .= "



			<div class='homepage-gallery-icon'>

				$link
	
			</div>";

		$n++;

		if ( $captiontag && trim($attachment->post_excerpt) ) {

			$output .= "

				<div class='carousel-caption'>

				" . wptexturize($attachment->post_excerpt) . "

				</div>";

		}

		$output .= "</div>";

	}

	$output .= "<ol class='carousel-indicators'>";
	$i = 0;
	$j = $n;

	while ( $i < $j ){

		$output .= " <li data-target='#myCarousel' data-slide-to='$i'></li> ";

		$i++;
	}

	$output .= "

		  </ol>

		  <a class='left carousel-control' href='#myCarousel' role='button' data-slide='prev'>

    <span class='glyphicon glyphicon-chevron-left' aria-hidden='true'></span>

    <span class='sr-only'>Previous</span>

  </a>

  <a class='right carousel-control' href='#myCarousel' role='button' data-slide='next'>

    <span class='glyphicon glyphicon-chevron-right' aria-hidden='true'></span>

    <span class='sr-only'>Next</span>

  </a> </div>";
    return $output;
}

/*Widget*/
include('geoformat_widget.php');
include('geoformat_duplicate.php');

//Dequeue styles and scripts
function unhook_theme_style_geoformat() {
	global $wp_query;
	$post_type = get_query_var('post_type');
	if($post_type == 'geoformat' ) {
		wp_dequeue_style( 'style' );
		wp_deregister_style( 'style' );
		wp_register_style( 'style', false );
	}
}
add_action( 'wp_enqueue_scripts', 'unhook_theme_style_geoformat', 9999 );

function de_script_geoformat() {
		global $wp_query;
		$post_type = get_query_var('post_type');
		if($post_type == 'geoformat' && !is_admin() ) {
		   
		   wp_dequeue_script( 'gp_frontend_js' );
		   wp_deregister_script( 'gp_frontend_js' );
		}
	}
	add_action('wp_print_scripts', 'de_script_geoformat', 100 );
?>