<?php
/**
 * The Default Sidebar
 *
 * @package GeoProjects
 */
?>
<div id="secondary" role="complementary">

	<?php /* LASTS MAPS */ ?>

	<?php
	gp_the_side_last_maps();
	gp_the_side_last_geoformat();
	?>

</div>